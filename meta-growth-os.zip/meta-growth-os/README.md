# HMM Meta Growth OS

A staged operating system for Meta Ads — the paid half of the HMM Growth OS family, built to the same architecture as the [SEO Growth OS](https://helpmemarketing.com/seo-growth-os).

One orchestrator plus twelve specialists, running a single pipeline:

**Discover → Audit → Diagnose → Prioritize → Execute → Monitor → Report → Schedule**

Every run builds an Obsidian-compatible vault of interlinked notes and a self-contained HTML dashboard.

## Two pillars

Everything resolves against one of two business models. The pillar is established in Stage 1 and changes the benchmarks, the funnel definition, the scoring emphasis and the decision rules.

| Pillar | You buy | You get paid on | The core problem |
|--------|---------|-----------------|------------------|
| **Service & Lead Generation** | A lead | A closed deal | The platform cannot see your real success metric unless you send it back |
| **E-commerce** | A purchase | Contribution margin | The platform sees the purchase but not the margin, the return, or the incrementality |

## Skills

| Skill | Weight | Answers |
|-------|--------|---------|
| `meta-growth-os` | — | The orchestrator. Start here |
| `meta-signal` | 20% | Is the account measuring the right thing, correctly? |
| `meta-creative` | 18% | Is the creative earning attention, and is it fresh? |
| `meta-structure` | 16% | Can the algorithm actually learn, and is budget where it should be? |
| `meta-funnel` | 14% | What happens after the click? |
| `meta-audience` | 12% | Is the audience right, and is it used up? |
| `meta-columns` | 10% | Can the operator see the truth in their own reporting? |
| `meta-audit` | — | Fans out to all six, scores the account |
| `meta-benchmarks` | — | Published medians with confidence marking, plus target derivation |
| `meta-drift` | — | Did anything break since last time? |
| `meta-report` | — | Audience-tuned reporting and the dashboard |
| `meta-setup` | — | Readiness check — Tier 1 connectors block, Tier 2 branches. Runs once per environment |
| `meta-memory` | — | Account memory in Google Drive — looks the account up before asking anything, saves contract/findings/report per run |

**Signal carries the heaviest weight on purpose.** This is the inverse of the SEO OS, where content quality leads. In paid, measurement leads — an account with perfect creative optimising toward a mis-fired event is spending efficiently in the wrong direction.

## Commands

```
run <account>        Discover → Report, then stops. The default.
discover <account>   Pillar, unit economics, derived targets
audit <account>      Full health check → scored Audit Report
diagnose             Broken / Missing / Leaking gap inventory
prioritize           Impact × Effort × Confidence × Time → roadmap
execute [item]       Produce the fixes. Draft-first, paused-first
monitor <account>    Drift baseline and regression detection
report [audience]    Founder / client / internal + HTML dashboard
schedule <account>   Recurring runs, exception-only reporting
bench <pillar>       Fast path: benchmark lookup
columns              Fast path: build L1/L2/L3 column presets
status               What's complete, what's next
```

## What you need connected

| Tier | Connector | Behaviour |
|------|-----------|-----------|
| **1 — Required** | Meta Ads connector · Google Drive | **Blocks.** No connector, no account to read. No Drive, no memory — every run re-interviews from scratch |
| **2 — Down-funnel** | CRM (Service) · Commerce platform (E-commerce) | Never blocks. The setup skill asks which platform you use and branches to a connector or an export |

`meta-setup` runs on the first invocation in an environment, reports what's connected in a
readiness table, and states what each gap costs in outcome terms. It detects by
**capability, not connector name** — names drift between environments and are sometimes
misspelled, and a name-matched check reports failures against working connectors.

**Limited Mode** is the sanctioned exception: if the Meta connector genuinely cannot be
added — no API access, IT restriction, or a prospect's account being audited pre-sales —
the audit runs from CSV exports with unverifiable items marked `Needs Confirmation` and a
banner on every report. Drive is still required. A Limited Mode audit is real; it simply
must never be mistaken for a connected one.

## Account memory

Every run is keyed to the ad account ID and persisted to Google Drive under
`HMM Meta Growth OS / {account id} — {account name}/`. The first run interviews the client
and saves the Intake Contract; every run after that **looks the account up before asking
anything**, presents what is on file, and walks only what changed.

Storage is append-only dated Google Docs — the connector cannot update file content, and
the version history is the audit trail anyway. Findings carry stable IDs so a second audit
can classify each one as Resolved / Persisting / New / Regressed. No customer PII is ever
written.

## Safety model

This OS touches accounts that spend real money, so the guardrails are stricter than the SEO equivalent:

- **A run stops at Report.** Execute and Schedule are opt-in.
- **Draft-first, paused-first, one item at a time.** No bulk pauses, no budget changes, no audience edits without explicit per-item confirmation.
- **Learning-phase warnings are mandatory.** Any recommendation that resets learning says so and estimates the cost.
- **Stage 1 stops without unit economics.** Every target derives from them; an audit scored against an invented target is worthless.
- **Special Ad Category check** before any targeting recommendation in finance, health, housing, employment or credit.
- **No customer PII in the vault.**

## Benchmarks

`meta-benchmarks/references/benchmarks.md` carries published industry medians with the source, sample size and a confidence level on every figure — because published Meta benchmarks disagree with each other substantially (e-commerce ROAS circulates as both 1.86× and 3.71× for overlapping periods).

The library leads with **target derivation from unit economics**, not industry lookup:

- Service: `Target CPL = (deal value × margin × close rate) ÷ payback multiple`
- E-commerce: `Break-even ROAS = 1 ÷ contribution margin`

## Optional reasoning layer

If `ankit-logic` is installed it loads at Stage 4 and Stage 7. It is deliberately **not** bundled — downloads produce professional, voiceless output; runs with the layer installed carry the reasoning.

## Requirements

Works with no connectors at reduced depth. Deepens with a Meta Ads MCP connector, and — critically — with a CRM (Service) or commerce platform (E-commerce). Those two are the only sources that describe what actually happened rather than what the ad platform thinks happened. An account run without one is optimising a proxy, and the report says so.

---

*Built by Ankit kumar | HMM | helpmemarketing.com*
*For performance marketers and brand owners who want to think like Growth Architects, not media buyers.*
