---
name: meta-columns
description: "Build and audit Meta Ads Manager reporting — custom column presets for campaign, ad set and ad level, custom metrics (hook rate, hold rate, LPV rate), breakdown recipes, and verification that column names resolve in the live account. Use when the user asks about column presets, customise columns, which columns should I use, custom metrics in Meta, how do I see hook rate, my reporting is wrong, set up my Ads Manager view, or wants a reporting setup for Meta. Stage 2 and Stage 5 specialist in the HMM Meta Growth OS."
metadata:
  author: AnkitK
  brand: "HMM | helpmemarketing.com"
  version: "1.0.0"
  category: paid-social
---

# Meta Reporting & Column Presets

An operator can only act on what their reporting shows them. This category scores whether the account's own reporting surface tells the truth — and builds the presets that make it do so.

## Meta has no API for column presets

They are a per-user UI preference, absent from the Marketing API and from every connector. They must be built by hand, once. A saved preset is then available across every ad account the user has access to, so it is a one-time job for the whole portfolio.

Deliver presets as a **build checklist**, never as a claim that they were created.

## Verify names before you hand over a list

Column display names drift between Meta releases, and several commonly-cited names are wrong or no longer exist. Where a Meta connector is available, resolve every column against the live field catalogue before publishing the list, and mark each row:

- **Verified** — resolved in the account's live field catalogue; the name shown is its exact current display name
- **Confirm in UI** — did not resolve in the connector's catalogue, which is a subset of Ads Manager. Absence is not proof it's gone
- **Custom** — not a Meta column; the user builds it as a custom metric

Names that commonly trip people up:

| Commonly written as | Actually |
|---------------------|----------|
| On-Facebook leads | **Meta leads** |
| CPP / cost per 1,000 people reached | **Cost per 1,000 Meta Accounts reached** |
| Budget | **Daily budget** and **Lifetime budget** — two separate columns |
| Schedule | **Stop time** (campaign) / **End time** (ad set) |
| First-time impression ratio | **Not a column at all** — Inspect panel only |
| Landing page views | Two exist — the plain one, and the narrower "Website landing page views" |
| CTR | Four exist — CTR (all), CTR (link click-through rate), Unique CTR, Outbound CTR |

Level restrictions also bite: **Attribution setting** and **Delivery sub-status** are ad-set level only; **Post shares** is not available at ad level.

## The three presets

Build one per level, named so the level is obvious.

**L1 — Campaigns.** Pacing and blended cost. Campaign name, Delivery, Objective, Daily/Lifetime budget, Amount spent, Stop time, Results, **Cost per result**, Meta leads, Website leads, Leads, Cost per lead, Registrations completed, Impressions, Reach, Frequency, CPM, Cost per 1,000 Meta Accounts reached, Link clicks, CTR (link click-through rate).

**L2 — Ad sets.** Learning and saturation. Everything cost-related from L1 plus **Delivery sub-status** (the learning-phase column), **Performance goal**, **Attribution setting**, Bid strategy, CPC (link), Landing page views, Cost per landing page view, LPV Rate.

**L3 — Ads.** Creative diagnosis. Cost columns plus 3-second video plays, Hook Rate, ThruPlays, Hold Rate, Video plays at 25/50/75/95/100%, Video average play time, Quality ranking, Engagement rate ranking, Conversion rate ranking, Post comments, Post reactions, Post saves.

**Cost per result is the column to rank on** at every level. It is already de-duplicated and it self-labels the result type — returning, for example, a figure tagged "(Leads (form))" on Instant Form ad sets and "(Website leads)" on landing-page ad sets. One column, correct cost, form type visible.

## Custom metrics

Built via Customise Columns → Create Custom Metric. Pick from autocomplete rather than typing names free-hand.

| Name | Formula | Format |
|------|---------|--------|
| Hook Rate | 3-second video plays ÷ Impressions | Percentage |
| Hold Rate | ThruPlays ÷ 3-second video plays | Percentage |
| LPV Rate | Landing page views ÷ **Outbound clicks** | Percentage |
| IF Lead Share | Meta leads ÷ Leads | Percentage |

**Check the numerator is populated first.** Building Hook Rate on a metric the account barely records produces a number that reads as catastrophic failure and is an artefact. Pull raw counts before recommending a formula.

LPV Rate divides by outbound clicks, not link clicks — Instant Form link clicks never leave Meta.

## Breakdowns stay out of presets

A breakdown saved into a preset forces a segmented view every time it opens. Document them separately and apply on demand: Platform, Placement, Age, Gender, Region, Impression device, Time of day, and By Time → Weekly for fatigue curves.

Some breakdowns now require account-level enablement. If one returns empty, that is an access setting, not missing data — check before reporting it as a gap.

## Output

Three ordered column lists with a verification status per row and a search keyword for each, the custom metric formulas, the breakdown recipes, and a note on any column that could not be verified.

## Hard rules

- Never claim a preset was created. They cannot be created programmatically.
- Never publish a column name without either verifying it or marking it unverified.
- Never build a ratio without checking the numerator has volume.

---
*Built by Ankit kumar | HMM | helpmemarketing.com*
