---
name: meta-memory
description: "Account memory for the Meta Growth OS — saves and retrieves the Intake Contract, findings register and reports per ad account in Google Drive, so a second run on the same account starts from what was already established instead of re-interviewing from scratch. Use when starting any Meta audit or Growth OS run, when the user asks what did we find last time, what changed since the last audit, load the contract for this account, save this audit, or where is the record for this client. Invoked automatically by meta-audit Phase 1 and meta-growth-os Stage 1."
metadata:
  author: AnkitK
  brand: "HMM | helpmemarketing.com"
  version: "1.1.0"
  category: paid-social
---

# Meta Account Memory

The OS's long-term memory. Without it, every run re-interviews the client and every audit is a first audit. With it, run two starts from confirmed ground and can answer the question that actually matters: **what changed?**

Read `references/drive-mechanics.md` before the first read or write in a session — it carries the connector's verified constraints and the exact call patterns.

## The one-screen version

| | |
|---|---|
| **Where** | Google Drive → `HMM Meta Growth OS` → one folder per ad account |
| **Keyed by** | Ad account ID — the only identifier that never changes |
| **Format** | Google Docs, human-readable. Client can open and edit them |
| **Updates** | **Append-only.** New dated file each time; newest wins. Never overwrite |
| **Saves at** | Each gate closing, after a one-time location confirmation |
| **Fallback** | No Drive → local vault, and the report says memory was not persisted |

## Folder layout

```
HMM Meta Growth OS/
└── act_155335638649619 — Equiton Facebook/
    ├── ACCOUNT CARD                        ← newest state, recreated each run
    ├── CAPABILITY RECORD — 2026-08-19       ← what was connected, per run
    ├── INTAKE CONTRACT — 2026-08-19        ← dated, append-only
    ├── INTAKE CONTRACT — 2026-11-02        ← newest = current truth
    ├── FINDINGS — 2026-08-19
    ├── REPORT — 2026-08-19
    └── RUN LOG — 2026-08-19
```

Folder title is always `{account_id} — {account name}`. The account ID leads because it is
the stable key; the name is for humans and may change.

## The run sequence

### 1. Look up before you ask anything

Search Drive for the account ID **before the first question**. This is the whole point —
asking a returning client to redraw their funnel is the failure this skill exists to prevent.

- **No folder found → cold start.** Create the folder, run the full Intake Contract
  (`meta-audit/references/intake-gate.md`), save it.
- **Folder found → warm start.** Read the newest `INTAKE CONTRACT`, then go to step 2.

### 2. Warm start — present, don't assume

Show the client what is on file and ask what changed. Never load a stored contract silently
and proceed: a contract from six months ago is a hypothesis wearing a timestamp.

> Found a contract for this account from 19 Aug 2026, confirmed by Ankit.
> It records: lead generation · end goal "Treatment" · funnel Lead → QL → Appointment →
> Visit → Treatment · source of truth HubSpot.
> **Has anything changed since then?**

Then, whatever the answer:

- **Nothing changed** → write a new dated contract marked `reconfirmed, no changes`, with
  today's confirmation line. The re-confirmation itself is the record.
- **Something changed** → walk only the changed items, write a new dated contract, and record
  what moved. Changed funnel stages, a changed end goal or a changed source of truth are
  **findings in their own right** — they usually invalidate period-over-period comparison,
  and the report must say so.

### 3. Diff the findings

With a previous `FINDINGS` file, classify every finding in the new run against it by ID:

| Class | Meaning |
|---|---|
| **Resolved** | Was present, now absent. The most valuable line in any second audit |
| **Persisting** | Present both times — and note how long. A finding surviving three audits is an organisational problem, not a technical one |
| **New** | Absent before, present now |
| **Regressed** | Was resolved, has returned |

Never claim Resolved without positive evidence it is gone. Absence from this run's output
because a category was not assessed is **not** resolution — check coverage first.

### 4. Save at each gate

After the one-time location confirmation, write automatically as each gate closes: the
contract when Phase 1 / Stage 1 closes, findings when the audit completes, the report when
it is produced. A dropped session then costs the analysis, never the interview.

## What is stored, and what is never stored

**Stored:** the capability record from `meta-setup` (which connectors were present, which confirmed absent, the Tier 2 route chosen, whether Limited Mode was used) · declared truths in the client's own words · the funnel stage table · the
optimisation-event map · unit economics and derived targets · the findings register with
stable IDs · the final report · confirmation lines with names and dates.

**Never stored:** customer PII, lead names, emails, phone numbers, raw lead exports, ad
account access tokens, or anything that would make the folder a liability if shared. The
memory holds business facts and analysis — never the client's customer list.

## Standalone use

Runs on its own, outside any audit:

- *"What did we find last time for Equiton?"* → read newest FINDINGS, summarise
- *"Load the contract for act_1553…"* → read and present it
- *"What changed since the last audit?"* → diff the two newest FINDINGS files
- *"Which accounts have we audited?"* → list folders under the root
- *"Save this audit"* → write the current session's analysis into the account folder

## Hard rules

1. **Look up before asking.** Searching Drive precedes the first question, always.
2. **Never silently reuse a stored contract.** Present it, ask what changed, get a fresh
   confirmation line. Every time.
3. **Append, never overwrite.** The connector cannot update file content anyway
   (`references/drive-mechanics.md`), and the version history is worth having regardless.
4. **Never trash a prior contract, findings file or report.** History is the asset.
5. **A changed contract invalidates comparison.** Say so rather than comparing across it.
6. **No PII.** Ever.
7. **Confirm the location once per run** before the first write, then save automatically.
8. **If Drive is unavailable**, say so plainly, fall back to the local vault, and record in
   the report that memory was not persisted — never fail silently and never pretend a save
   happened.

---
*Built by Ankit kumar | HMM | helpmemarketing.com*
