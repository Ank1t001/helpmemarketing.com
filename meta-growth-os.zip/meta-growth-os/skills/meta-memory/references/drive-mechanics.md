# Drive Mechanics — verified connector behaviour

Everything here was tested against the live Google Drive connector on 19 Aug 2026.
These are not assumptions about how Drive *should* work — they are what it *does*.
Read this before the first read or write in a session.

---

## Constraint 1 — file content cannot be updated

`update_file` accepts **only** `title` and `parentId`. There is no content parameter.
Once a file is written, its content is immutable through this connector.

**Therefore: append-only, versioned files.** Never plan a "living document" that gets
edited each run. Each run writes a new dated file; the newest matching title wins. This
is also better practice — the version history is the audit trail, and a client can see
exactly what was declared when.

Do not attempt a read-modify-recreate-trash cycle to simulate updates. It risks losing
the record if any step fails, and history is the asset.

## Constraint 2 — the reader escapes markdown punctuation

Reading any file back returns content with `_`, `#`, `[` and `]` escaped with backslashes,
regardless of the stored mime type. Verified identically across `text/markdown`,
`application/json` and native Google Docs.

Stored: `{"account_id":"act_155335638649619"}`
Returned: `{"account\_id":"act\_155335638649619"}` — **invalid JSON**

**Therefore, three rules:**

1. **Never store machine-parsed JSON in Drive.** It will not round-trip. Store
   human-readable prose and tables, and re-interpret them on read the way a person would.
2. **On read, mentally un-escape** `\_` → `_`, `\#` → `#`, `\[` → `[`, `\]` → `]`.
   Deterministic and safe.
3. **Prefer field labels without underscores or hashes** — write `account id` and
   `end goal`, not `account_id` and `end_goal`. The stored document then reads cleanly for
   humans and comes back nearly clean for the machine.

Characters that survive untouched: letters, digits, hyphens, pipes, colons, parentheses,
em-dashes. **Pipe tables round-trip perfectly** — which is why every stored structure in
this system is a pipe table.

## Constraint 3 — search is title-first

`search_files` supports `title contains`, `fullText contains`, `parentId =`, `mimeType`,
and time comparisons. It does not support wildcards or regex.

**Therefore the naming convention is load-bearing.** Titles must be predictable:

| Purpose | Title pattern | Lookup |
|---|---|---|
| Account folder | `{account id} — {account name}` | `title contains '{account id}'` |
| Contract | `INTAKE CONTRACT — YYYY-MM-DD` | `parentId = '{folder}' and title contains 'INTAKE CONTRACT'` |
| Findings | `FINDINGS — YYYY-MM-DD` | `parentId = '{folder}' and title contains 'FINDINGS'` |
| Report | `REPORT — YYYY-MM-DD` | `parentId = '{folder}' and title contains 'REPORT'` |
| Card | `ACCOUNT CARD` | `parentId = '{folder}' and title contains 'ACCOUNT CARD'` |

ISO dates in titles sort lexicographically, so "newest" is the last title alphabetically —
no metadata call needed. Use `createdTime` as the tiebreaker if two share a date.

## Constraint 4 — folder creation is a create_file call

Create a folder with `contentMimeType: application/vnd.google-apps.folder` and no content.
Nest by passing `parentId`. Returns an `id` and a `viewUrl` — **surface the viewUrl to the
user** so they can open the folder themselves.

## Call patterns

**Find or create the account folder**

1. `search_files` with `title contains '{account id}'`
2. If a folder is returned, use its `id`
3. If not: `search_files` for `title contains 'HMM Meta Growth OS'` to get the root
   (create it if absent), then `create_file` the account folder inside it

**Write a document**

`create_file` with `title`, `parentId`, `contentMimeType: text/plain`, and `textContent`.
Omit `disableConversionToGoogleType` so it becomes a native Google Doc — readable in the
Drive UI and editable by the client, which a raw `.md` blob is not.

**Read the newest of a kind**

`search_files` with `parentId = '{folder}' and title contains 'INTAKE CONTRACT'`, sort the
returned titles, take the last, then `read_file_content` on its `id`.

## Storage format

Every stored document is a Google Doc using pipe tables and plain-language labels. Example
shape for the contract — the labels avoid underscores on purpose:

```
Intake Contract — Equiton Facebook

account id: act-155335638649619        ← hyphens, not underscores, in labels
contract date: 2026-08-19
confirmed by: Ankit Kumar, 2026-08-19
status: confirmed | reconfirmed no changes | unconfirmed (relative mode)

Declared truths
| Item | Client's words | Status |
| Business model | Lead generation | Confirmed |
| End goal | Treatment | Confirmed |

Funnel — client's own stage names
| # | Stage | Measured in | Owner | Gap |
| 1 | Lead | Meta + HubSpot | Marketing | none |
| 2 | Qualified Lead | HubSpot | Sales ops | manual tagging |
```

Note: the *account ID itself* keeps its real underscores wherever it must be matched
(folder titles, search queries). Only descriptive labels avoid them.

## Failure handling

| Situation | Action |
|---|---|
| Drive not connected | Say so, use the local vault, record "memory not persisted" in the report |
| Root folder missing | Create it, surface the viewUrl |
| Two folders match one account ID | Stop and ask which is canonical — never guess |
| A file reads back empty or truncated | Report it; do not treat empty as "nothing was found" |
| Write fails mid-run | Tell the user immediately and offer the content inline so nothing is lost |
