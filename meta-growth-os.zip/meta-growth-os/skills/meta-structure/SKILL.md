---
name: meta-structure
description: "Audit and redesign Meta Ads account architecture — campaign and ad set structure, consolidation, learning phase and Learning Limited diagnosis, budget allocation and pacing, CBO vs ABO, bid strategy, and testing structure. Use when the user asks about account structure, campaign structure, how many ad sets, should I consolidate, Learning Limited, learning phase, CBO or ABO, budget allocation, how to scale my Meta campaigns, or my ad sets aren't spending. Stage 2 specialist in the HMM Meta Growth OS."
metadata:
  author: AnkitK
  brand: "HMM | helpmemarketing.com"
  version: "1.0.0"
  category: paid-social
---

# Meta Account Structure

Structure exists to serve one thing: giving the delivery system enough events per ad set to learn. Most structural problems are the same problem — the account is cut into more pieces than its conversion volume can support.

## The arithmetic that decides everything

**Weekly conversions ÷ number of ad sets ≥ 50.**

Run it before any other structural opinion. An account with 200 conversions a week supports four ad sets, not fourteen. Every ad set below ~50 optimisation events per week sits in Learning Limited and delivers at inflated cost — so over-segmentation isn't a stylistic preference, it's a direct tax.

Meta exposes this as **Delivery sub-status** at ad set level: `LEARNING`, or `FAIL` which displays as "Learning limited". It is ad-set level only — the campaign-level Delivery column does not carry it.

## What to check

**Learning phase**
- How many ad sets are in Learning Limited, and what share of spend do they hold?
- How many exited learning, and how long did it take? Over 7 days signals insufficient volume.
- How often are live ad sets being edited? **Significant edits reset learning.** A weekly cadence of small tweaks can hold an account permanently in its most expensive delivery state. Check edit frequency before blaming the auction.

**Consolidation**
- Ad sets targeting overlapping audiences with the same creative — merge them.
- Ad sets under ~50 events/week that could be merged without losing a real strategic distinction.
- The test: if you cannot name a decision you would make differently based on this ad set's separate data, it should not be separate.

**Budget & pacing**
- Spend vs plan per campaign; flag >±15% off pace.
- Is budget concentrated in above-median-cost campaigns while below-median campaigns sit capped? This is the most common free money in any account.
- CBO vs ABO: CBO for scale once winners are known; ABO for controlled testing where you need guaranteed spend per cell.
- Bid strategy: cost caps and bid caps throttle delivery. If an ad set is underspending, check the cap before concluding the audience is exhausted.

**Testing structure**
- Is there a dedicated testing surface, or is new creative dropped into scaling campaigns where it disturbs a working ad set?
- Are tests structured so a result is attributable? One variable at a time.

**Naming convention**
- Does the naming encode what you need to segment by? For Service that means form type (Instant Form vs landing page); for E-commerce, prospecting vs retargeting and product category. Without it, segmented analysis becomes manual every single time. This is a small fix with compounding returns.

## Recommendations that need a warning label

Any consolidation, budget change over ~20%, optimisation-event change or audience edit **resets learning**. When recommending one, say so and estimate the cost: roughly the learning period's spend at elevated CPA. That is often still worth it — but the user should choose knowingly.

## Output

A structure map (campaigns → ad sets → weekly events → delivery sub-status → spend share), a consolidation plan naming which ad sets merge and why, a budget reallocation table, and every recommendation flagged for whether it resets learning.

## Hard rules

- Never recommend more ad sets than weekly conversion volume ÷ 50.
- Never recommend a structural change during an active learning phase without saying it restarts the clock.
- Never bulk-pause. Structural changes go one at a time, paused-first, with human confirmation.
- Never judge an ad set that hasn't cleared ~50 conversions.

---
*Built by Ankit kumar | HMM | helpmemarketing.com*
