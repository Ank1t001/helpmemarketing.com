---
name: meta-audience
description: "Audit Meta Ads targeting and audience health — saturation and frequency, audience overlap between ad sets, placement performance, demographic and geographic cost breakdowns, exclusion hygiene, custom and lookalike audience strategy, and broad vs granular targeting. Use when the user asks about audience saturation, ad fatigue, frequency too high, audience overlap, which placements to cut, targeting strategy, lookalike audiences, retargeting setup, should I go broad, or my CPMs are rising. Stage 2 specialist in the HMM Meta Growth OS."
metadata:
  author: AnkitK
  brand: "HMM | helpmemarketing.com"
  version: "1.0.0"
  category: paid-social
---

# Meta Audience & Targeting

Targeting is now the lowest-leverage lever in most accounts — broad targeting with strong creative beats granular targeting with weak creative. So the job here is mostly defensive: find where the audience is exhausted, where you're bidding against yourself, and where budget leaks into placements that never convert.

## Saturation

Three signals, read together. Any one alone is ambiguous.

| Signal | Saturating | Not saturating |
|--------|-----------|----------------|
| Frequency | Climbing past 3–4 on cold and still rising | Stable, or high on a deliberately warm audience |
| Reach vs spend | Reach flattening while spend rises | Reach growing proportionally |
| Cost per 1,000 reached | Rising on unchanged targeting | Flat |

**First-time impression ratio** is the cleanest signal but is **not a column** — it lives in the Inspect panel (Ad Sets tab → hover the row → Inspect → Audience saturation), ad-set level only, auction campaigns only, and needs delivery volume to render. Use the three columnar signals above as the working substitute.

Frequency ceilings are audience-temperature dependent. 3–4 is a cold-prospecting guide. Retargeting tolerates far more, and a high frequency on a small warm pool is expected, not a fault.

## Overlap

Ad sets bidding against each other inflate your own CPM — you are paying a premium to compete with yourself. Overlap is **not a column**: use Audiences → select 2–5 → Actions → Show Audience Overlap. Consolidate above ~30%.

A high account-level frequency alongside healthy per-campaign frequencies is the fingerprint of cross-campaign overlap. Check it whenever those two disagree.

## Placement

Break spend down by placement and look for the classic pattern: meaningful spend, no conversions. Audience Network is the usual culprit — it carries the lowest CTR of any placement by a wide margin.

Before cutting: check whether the placement is cheap enough that its poor conversion rate still nets out. Cutting a placement that delivers at a fifth of the CPM can raise blended cost.

## Demographic and geographic breakdown

Break cost per result down by age, gender and region. Exclude segments running above ~1.5× the account median for 7+ days with enough volume to be real.

Cross-check against who actually *converts down-funnel*, not who converts on-platform. A segment that produces cheap leads and no closed deals should be excluded even though the ad platform is calling it a winner.

**Regulated verticals — stop here first.** Finance, health, housing, employment and credit fall under Special Ad Categories, where age, gender and detailed geographic targeting are restricted. A demographic exclusion recommendation in these verticals can be non-compliant. Check category status before recommending anything.

## Exclusion hygiene

The most commonly missing items, and the cheapest to fix:
- Existing customers excluded from prospecting (unless deliberately retargeting for repeat)
- Converters excluded from acquisition campaigns
- **Service:** current leads, existing pipeline and closed-lost excluded from lead-gen
- **E-comm:** recent purchasers excluded from prospecting; window matched to repurchase cycle
- Employees and internal traffic excluded

## Custom and lookalike strategy

- Seed quality beats seed size. A 500-person list of closed-won customers usually outperforms a 50,000-person list of all leads.
- **Service:** build lookalikes from *closed deals*, not from leads. A lookalike of your leads is a lookalike of people who fill in forms.
- **E-comm:** build from high-LTV or repeat purchasers, not all purchasers.
- Broader lookalike percentages perform closer to broad targeting than most people expect; the 1% premium is often not worth the reach cost.

## Output

A saturation table per ad set (frequency, reach trend, cost per 1,000 reached), an overlap finding list, a placement spend-vs-result table, segment exclusion candidates with the evidence for each, and an exclusion-hygiene checklist with what's missing.

## Hard rules

- Never diagnose saturation from frequency alone.
- Never recommend demographic targeting changes in a Special Ad Category without checking compliance.
- Never exclude a segment on on-platform conversion data alone when down-funnel data exists.
- Never judge an audience inside the learning phase.

---
*Built by Ankit kumar | HMM | helpmemarketing.com*
