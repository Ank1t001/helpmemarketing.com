---
name: meta-creative
description: "Audit and improve Meta Ads creative — hook rate and hold rate diagnosis, creative fatigue curves, CTR and cost-per-result ranking by ad, creative testing structure, format and placement fit, ad relevance diagnostics, and creative brief generation. Use when the user asks about creative performance, hook rate, hold rate, thumbstop rate, ad fatigue, creative refresh, which ads to kill, why my ads stopped working, creative testing, video retention, or wants creative briefs for Meta. Stage 2 and Stage 5 specialist in the HMM Meta Growth OS."
metadata:
  author: AnkitK
  brand: "HMM | helpmemarketing.com"
  version: "1.0.0"
  category: paid-social
---

# Meta Creative

Creative carries more variance than any lever except the offer. The spread between an account's best and worst creative routinely dwarfs the spread between its audiences — which is why creative diagnosis pays more than targeting work in almost every account.

## The two ratios that explain why

Cost tells you *that* an ad underperforms. These tell you *why*.

| Metric | Formula | Diagnoses |
|--------|---------|-----------|
| **Hook rate** (thumbstop) | 3-second video plays ÷ Impressions | The first frame, thumbnail and opening second |
| **Hold rate** | 15-second plays ÷ 3-second plays, or Video plays at 75% ÷ 3-second plays | The middle of the ad |

**Check the metric is populated before building either.** Some accounts have effectively zero 2-second continuous video plays while carrying millions of 3-second plays. Pull the raw counts first — a ratio built on an unpopulated numerator reads as catastrophic failure and is an artefact.

Note that 3-second video plays may not be available at ad level in every reporting surface. Where it isn't, read hook rate at ad-set level and use CTR (link) as the ad-level creative screen.

## Benchmark ranges

| Placement / temperature | Hook rate | Median |
|------------------------|-----------|--------|
| Cold prospecting, in-feed | 18–28% | ~22% |
| Reels | 24–36% | ~30% |
| Stories | 22–32% | ~27% |
| Retargeting / warm | 30–45% | ~36% |

**Retargeting hook rate is not a creative-quality signal.** Warm audiences stop because they recognise you. Never benchmark cold creative against a warm number, and never let a retargeting-heavy blended average flatter a weak prospecting hook.

| Hold rate measure | Healthy | Best in class | Act below |
|-------------------|---------|---------------|-----------|
| 15-second ÷ 3-second | 15–25% | 25–30% | 10% |
| Video plays at 75% ÷ 3-second | 8–15% | — | — |

## The diagnosis grid

| | Low hold | Good hold |
|---|---|---|
| **Low hook** | Concept is wrong. Rebuild, don't re-edit. | Works for whoever watches. Fix only the first frame, thumbnail and opening line. **Cheapest possible win.** |
| **Good hook** | Clickbait — the opening promised what the body didn't deliver. Re-edit. | Creative is fine. Go back to the diagnostic order: auction, audience or landing page. |

Roughly 70% of retention problems are pacing problems, fixable by re-editing rather than re-shooting: tighten cuts, land the value proposition by second 5, break up the dead zone between seconds 8 and 15, add an outcome shot.

## Fatigue

Creative fatigue is a *time* pattern, not a level. Apply a weekly time breakdown and read cost per result across weeks per ad. **Two consecutive weeks of rising cost per result on a previously-winning ad is the refresh signal.**

Distinguish it from audience fatigue: if every ad in the ad set degrades together, that's the audience. If one ad degrades while its siblings hold, that's the creative.

## Ranking and killing

Rank on **cost per result**, not cost per lead — it's de-duplicated and it self-labels the result type. Kill the bottom third, but only:
- within one form type or funnel stage (never compare Instant Form against landing page, or prospecting against retargeting)
- after the judgement window — 3–7 days *and* ~50 conversions
- when no single fixable cause is visible

**Ad relevance diagnostics** — Quality ranking, Engagement rate ranking, Conversion rate ranking — need 500+ impressions to compute. Below average on quality with good cost is usually noise; below average on conversion rate ranking points at the landing page, not the ad.

## Testing structure

- One variable per test. A test that changed hook, format and copy teaches nothing repeatable.
- Roughly 100 conversions per variant before a 20% difference is trustworthy. Most "winners" declared at 20 conversions are coin flips.
- Test hooks against a fixed body before testing whole concepts — it isolates the cheapest lever.
- Winning creative gets scaled into a fresh ad set rather than having its budget raised in place, which resets learning.

## Brief generation (Stage 5)

Every brief carries: the diagnosis it answers (which grid cell), the specific hook direction, the beat-by-beat structure with timings, the format and placement it's cut for, the aspect ratios needed, the claim substantiation required, and the compliance constraints for the vertical. Draft-first — flag every claim a human must verify.

## Hard rules

- Never compare cold and warm creative metrics.
- Never build a ratio without checking the numerator is populated.
- Never kill a creative inside the judgement window.
- Never recommend a creative fix for what the diagnostic order shows is an auction or landing-page problem.
- Regulated verticals: check claim substantiation and Special Ad Category constraints before writing any brief.

---
*Built by Ankit kumar | HMM | helpmemarketing.com*
