# Conditional Path — Service & Lead Generation

Load when Phase 1 confirms the model is service / lead generation. Applies to
Phases 3, 4, 6 and 9. Everything here is read-only.

---

## Phase 3 addendum — the lead event chain

Trace a single lead through every hop, in order:

1. **Lead event** — which surface fires it: pixel on thank-you page, Instant Form, CAPI?
2. **Form submission** — does one submission fire exactly one event?
3. **Thank-you page** — reachable only post-submit? A crawlable thank-you URL inflates leads
4. **Instant Form integration** — form connected to the CRM directly or via middleware; middleware healthy
5. **CRM lead receipt** — pick 5 recent platform leads, find them in the CRM. Count the missing
6. **Qualified-lead event** — does one exist? Fired back to Meta? This is usually the biggest absence in the account
7. **Booked-meeting event** — same question
8. **Offline conversion feedback** — closed-won returning to an offline event set, with values

If hops 6–8 are absent, record it as one `Missing` finding, not three: the account has no
path from proxy to money.

## Phase 4 — the funnel to map

**The funnel comes from the Intake Contract — the client drew it, in their own stage
names. The chain below is an EXAMPLE SHAPE for the auditor's orientation only. Never
present it to the client as a starting point, never use it as a default, and never
rename the client's stages to match it.** A dental clinic runs Lead → QL → Appointment
→ Visit → Treatment; an investment firm runs Lead → Booked Meeting → Completed Meeting
→ Client. Same pillar, different shapes — and the stages a template merges are usually
where the money leaks.

Example shape only:

```
Impression → Click → Landing Page View / Form Open → Lead → Verified Lead
→ Qualified Lead → Booked Meeting → Completed Meeting → Customer
```

For every stage record: measurement system · event or CRM field · volume in the audit
period · conversion rate from prior stage · cost · **data owner** (who fixes it when it
breaks) · known tracking gaps.

Stages past "Lead" usually live in the CRM. If the CRM is unavailable, the funnel map
stops honestly at Lead and every stage after it is `Needs Confirmation` — the report must
then say all cost judgements are per-lead, not per-outcome, and what that hides.

**Two funnels if both form types run.** Instant Form and landing-page leads convert
downstream at different rates. Map them separately or the blend hides the difference —
which is the single most decision-relevant number in a mixed account.

## Phase 6 addendum — judging lead performance

- Rank on **cost per result** (de-duplicated, labels its form type), never plain CPL
- Compare within a form type only; IF vs LP comparison happens at the *qualified* stage or later
- Pull **cost per qualified lead and per booked meeting by campaign** wherever CRM data allows.
  Expect inversions — the cheapest-lead campaign is often the most expensive per meeting
- **Conversion lag:** if the sales cycle exceeds the attribution window, recent campaigns are
  systematically under-credited. Note the lag from Phase 1 and shade the reading accordingly

## Phase 9 — forms and landing pages

**Instant Forms:** form type (more volume vs higher intent — which was chosen, and was it
deliberate?) · questions (any qualification at all?) · qualification logic · privacy policy
link valid · review step on or off (off = cheaper and worse) · thank-you screen and next
step · CRM delivery per form · **Lead Access Manager permissions** (the classic silent
failure: leads collected, nobody can download them) · duplicate/spam lead rate ·
**form-to-qualified rate vs the landing-page path**.

**Landing pages:** message match with the ads that point at it · mobile experience first
(Meta traffic is overwhelmingly mobile) · load speed · form works (submit one) · field
count vs lead quality intent · CTA above the fold · trust indicators · compliance
(required disclaimers for the vertical) · thank-you page fires the conversion exactly
once · UTMs survive the redirect chain · page conversion rate by traffic source.

**Regulated verticals** (finance, insurance, health, real estate, credit, employment):
check Special Ad Category status, claim substantiation on the pages, and required
disclosures **before** any targeting or copy observation is written up. A compliance gap
outranks every performance finding in the report.
