# Conditional Path — E-commerce

Load when Phase 1 confirms the model is e-commerce. Applies to Phases 3, 4, 6 and 9.
Everything here is read-only.

---

## Phase 3 addendum — the purchase event chain

**First, the optimisation-event check against the Intake Contract.** List what every ad
set optimises toward and set it against the declared end goal. If campaigns optimise for
AddToCart and the contract says the goal is Purchase, the contract records whether the
client called that deliberate. If they did not, it is a candidate finding here — judged
on volume arithmetic (does Purchase clear ~50/week per ad set? if not, the intermediate
event may be the defensible choice) rather than on the assumption that closer-to-money
is always right.


Verify each event exists, fires once, and carries the right parameters:

| Event | What to verify |
|---|---|
| ViewContent | Fires on product pages with `content_ids` |
| Search | Fires with the query |
| AddToCart | Fires once per add, with IDs and value |
| InitiateCheckout | Fires at checkout entry |
| AddPaymentInfo | Fires where the flow has the step |
| **Purchase** | Fires once per order — the one to test hardest |

Then: **product IDs** match the catalog (`content_ids` ↔ catalog retailer IDs — mismatch
breaks dynamic ads silently) · **purchase value** matches order totals (gross vs net,
tax/shipping in or out — pick one and confirm it's consistent) · **currency** matches the
account · **catalog matching** rate in Commerce Manager · **browser/server deduplication**
on Purchase specifically — a double-fired Purchase halves apparent CPA and the account
looks brilliant right up until the P&L disagrees.

**Order reconciliation:** platform-reported purchases vs the store's order count for the
same window. 20–30% platform over-count is expected; ~2× is a dedup failure. Also check
whether **refunds and returns** are deducted anywhere — they almost never are, and the gap
is invisible inside Ads Manager.

## Phase 4 — the funnel to map

**The funnel comes from the Intake Contract — the client drew it, in their own stage
names. The chain below is an EXAMPLE SHAPE for the auditor's orientation only, never a
default.** A subscription brand may run Trial → Activation → Paid; a high-AOV store may
insert Consultation before Purchase. Use their stages.

Example shape only:

```
Impression → Click → Product View → Add to Cart → Checkout → Purchase → Repeat Purchase
```

For every stage record: measurement system · event · volume · conversion rate from prior
stage · cost · data owner · known gaps.

Map **paid-traffic** stage rates separately from site-wide ones — paid cold traffic
converts below the blend, and comparing it to site-wide rates manufactures a fake problem.
Split prospecting from retargeting wherever volume allows; the blend hides weak
prospecting behind strong remarketing.

## Phase 6 addendum — judging purchase performance

- Platform ROAS is the start of the conversation, not the verdict. Cross-check against
  the store's revenue (MER) for the same window
- **Break-even ROAS = 1 ÷ contribution margin** — from Phase 1's confirmed economics,
  never assumed. Judge against that, not against a published median
- Separate **new-customer CAC from blended CAC** if the data allows; scaling decisions
  ride on the first, and the blend flatters it
- Pull **return rate by campaign** where the store exposes it — cheap traffic returns
  more, and a campaign with 15% lower CPA and 12 points more returns is the expensive one
- Check which SKUs the spend concentrates on vs their margins — the algorithm scales
  what converts, not what profits

## Phase 9 — product and checkout path

Product pages: message match with the ad (the product in the ad is the product on the
page, same price, same offer) · mobile experience · speed · reviews present · stock state
of advertised SKUs (spend pointing at out-of-stock products is a recurring silent leak).

Checkout: walk it on mobile · shipping-cost surprise timing · forced account creation ·
payment options for the market · the standard stage rates for context — cart→checkout
40–50% typical, cart abandonment ~70% — but judged against this store's own history per
operating rule 9, not against the reference range.

Catalog (where dynamic ads run): feed freshness and error rate · image quality at
placement sizes · price accuracy vs site · availability sync lag.
