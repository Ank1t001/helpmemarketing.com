# Audit Report Format

The output contract for every phase and for the final report. Using it identically on
every audit is what makes two audits comparable.

---

## Evidence statuses

Every finding carries exactly one:

| Status | Meaning |
|---|---|
| **Confirmed Issue** | Direct evidence shows a problem |
| **Suspected Issue** | Evidence suggests a problem but needs validation |
| **Needs Confirmation** | Required information is unavailable |
| **Opportunity** | Setup works, but improvement may be possible |
| **Pass** | Reviewed and no issue found |
| **Not Applicable** | Does not apply to this business |

Rules: never promote Suspected to Confirmed to make a report punchier. Never bury a
Needs Confirmation to make coverage look complete. Pass is a real status — a section
reviewed and found clean gets said, or the reader can't distinguish "fine" from "skipped".

## Phase status block

Presented at the end of every phase, before asking permission to continue:

```
Phase N Status: Pass / Issues Found / Blocked

Confirmed issues:
- ...

Suspected issues:
- ...

Needs confirmation:
- ...

Not applicable:
- ...

Questions:
- ...

Can the audit proceed safely?
- Yes / No (if No: what is blocked, and what remains auditable)
```

## Recommendation format

Every recommendation in Phase 11 carries all ten fields:

| Field | Content |
|---|---|
| Finding | What was observed, in one sentence |
| Evidence | Where it was seen — screen, export, event, reconciliation |
| Business impact | Stated in the business's own KPI from Phase 1, or "not quantifiable without X" |
| Recommended action | Specific enough that someone else could execute it |
| Priority | Critical (money actively wasted — same day) / High (within 1 week) / Medium (within 1 month) / Low (backlog) |
| Confidence | High / Medium / Low, tracking the evidence status |
| Dependencies | What must land first |
| Risk | What could go wrong doing it |
| **Resets learning?** | Yes/No — and if Yes, the estimated cost of the reset |
| Approval required | Yes/No — anything touching live spend is Yes |

## Final report structure

1. **Header** — business, account ID, currency, time zone, audit period, source of truth,
   the confirmed primary conversion, who confirmed Phase 1 and when
2. **Executive summary** — three findings maximum. More and none of them land
3. **Phase-by-phase results** — each phase's final status block, updated with anything
   later phases revealed
4. **Findings register** — every finding, ID'd (`AUD-001`…), with status and evidence.
   IDs are stable so the Growth OS Diagnose stage can trace gaps back to findings
5. **Recommendations** — the ten-field format, ordered by priority then confidence
6. **What could not be checked** — every `Needs Confirmation` and every blocked check,
   with what would unblock it. **Never ship this section empty**; if everything was
   assessed, say so explicitly
7. **Suggested next step** — by name (fix tracking first / proceed to Diagnose /
   collect data for N weeks), and why

## Tone rules

State observations, not accusations — "the pixel fires twice on /thank-you" not "the
tracking was set up wrong". Where a previous operator's choice looks odd, note it as
possibly intentional and ask. The report should be one the previous agency could read
without a lawyer and the next one could execute without a meeting.
