# Backend & Tracking Checklists — Phases 2 and 3

Read-only inspection. Nothing here changes a setting; everything here produces evidence
with a status: verified, issue found, or `Needs Confirmation`.

---

## Phase 2 — Backend and account integrity

### Business Portfolio

| Check | What good looks like | Common failure |
|---|---|---|
| Correct Business Portfolio | The portfolio the client actually owns | Auditing an agency's portfolio by mistake |
| Business ownership | Client owns their own portfolio | Agency owns it; client is hostage on departure |
| Business verification | Verified | Unverified — caps features and hurts trust signals |
| Security Center | No outstanding warnings | Ignored warnings, no recovery contacts |
| Two-factor authentication | Enforced for everyone | Optional or off |
| People access | Every person current, least privilege | Admin sprawl |
| Partner access | Every partner current and known | Old agencies still connected |
| Former employees or agencies | None present | The most common single finding in takeovers |
| System users | Each one mapped to a known integration | Orphaned system users with admin tokens |
| Connected integrations | Each one known and in use | Zombie integrations with data access |

### Ad account

| Check | Notes |
|---|---|
| Correct ad account selected | Confirm the ID with the user before auditing anything |
| Ad account ownership | Owned by the client's portfolio, not an agency's |
| Account ID, currency, time zone | Currency and time zone shape every report; note them in the audit header |
| Business country | Affects taxes and available features |
| Account spending limit | Present and forgotten limits silently stop delivery |
| Payment method + billing status | Backup card present? |
| Payment failures | Any in the period — these pause delivery and reset momentum |
| Tax information | Complete |
| Account Quality | Any restrictions, strikes, or pending reviews |
| Advertising restrictions | Account-, Page- or user-level |

### Connected assets

Facebook Page (published, unrestricted, admin access) · Instagram account (connected, correct one) ·
Dataset/Pixel (exists, correct one — verify the ID against the website's actual tag) ·
Domain (verified, correct apex) · Catalog if applicable (linked, feed healthy) ·
App if applicable · **Lead Access Manager** (who can download leads — a silent CRM-delivery
failure point) · CRM integration (present, firing) · Offline event source (exists? last upload?) ·
Custom audiences (sources still valid, no dead uploads).

### Phase 2 output

Use the status block from `audit-report-format.md`, ending with:
**Can the audit proceed safely? Yes / No.** If No, name the blocker.

---

## Phase 3 — Tracking and data integrity

Only begins once Phase 2 confirmed the correct assets.

### Core checks

| Check | How to evidence it |
|---|---|
| Correct dataset/pixel | ID on the website matches the ID in Events Manager matches the ID the ad sets optimise against |
| Pixel installation | Base code on all pages, once |
| Conversions API | Live? Last **server** fire time — a dataset can exist and be dead |
| Browser events vs server events | Both present where CAPI is claimed |
| Event deduplication | Shared `event_id` between browser and server. Missing dedup = inflated counts = deflated costs |
| Event IDs | Present, unique per event instance |
| Event Match Quality | Per event. Below ~6.0, matching is degrading optimisation — note which parameters are missing |
| Diagnostics | Open issues in Events Manager |
| Test Events | Run one if access allows; otherwise request the user runs one while you watch |
| Event volumes | Weekly volume per event vs what the business's activity implies |
| Incorrect or duplicate events | Two custom conversions on the same thank-you URL is one event counted twice |
| Event parameters | Present and populated, not just declared |
| Conversion values | Present where value matters; sane magnitudes |
| Currency | Event currency matches account currency |
| Domain association | Events associated with the verified domain |
| Custom conversions | Each one's rule inspected — URL rules that overlap standard events double-count |
| URL rules | Match the actual thank-you/confirmation URLs, including trailing-slash variants |
| CRM/offline conversions | Uploading? On what cadence? Match rate? |
| UTM parameters | Consistent scheme; campaign names parseable downstream |
| Attribution settings | Per ad set. **Mixed windows in one account is a finding** — costs across them are not comparable |
| Meta vs CRM/analytics discrepancy | Quantify it. 20–30% platform over-count is normal (view-through, cross-device); ~2× is a tracking bug |

### The Instant Form double-count

Meta's `Leads` action type folds `leadgen.other` and `onsite_conversion.lead_grouped`
together — the same submission under two labels. On IF campaigns `Leads` can read ~2× the
real count and `Cost per lead` ~half the real cost. Evidence it: compare `Leads` against
`Meta leads` on any IF campaign. Near 2:1 means it's live. Downstream phases must use
**Cost per result** (de-duplicated, self-labelling) or `Meta leads` — never plain CPL.

### Test conversion

Where access allows, fire a test event through Test Events and watch it arrive: browser
fire, server fire, dedup to one. Where it doesn't, ask the user to submit a test lead or
place a test order while Events Manager is open. If neither is possible, mark the entire
event chain `Needs Confirmation` — inspected configuration is not the same as observed
behaviour.

### Phase 3 gate

Pause the audit and say what is blocked if any of these hold:
wrong pixel/dataset may be connected · events are duplicated · the primary conversion
cannot be identified · purchase values are unreliable · CRM leads cannot be reconciled ·
any tracking issue that would make Phases 6–10 unreliable.

A paused audit is a finding, not a failure. "Your last 90 days of reporting cannot be
trusted because X" is frequently the most valuable sentence in the whole engagement.
