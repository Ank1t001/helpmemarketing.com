# Gate Zero — The Intake Contract

The hard gate before any analysis. Nothing in any phase of the audit — and nothing in
any stage of the Growth OS — proceeds until this contract is complete and the client has
confirmed it verbatim.

## The rule that governs everything here

There are two classes of information, and they are handled differently:

**Observable facts** — currency, time zone, account ID, which events fire, which
objectives run, what the campaigns currently optimise toward. The OS reads these from
the account and reports them as observations.

**Declared truths** — the business model, the funnel shape, the end goal, the primary
conversion, the source of truth, the targets, budget flexibility. These belong to the
client. The OS asks for them as **open questions** and records the answers **verbatim**.

The line the OS must never cross: **converting an observation into a pre-filled answer
for a declared truth.**

Wrong: "Your campaigns optimise for AddToCart, so your goal appears to be cart volume — confirm?"
Right: "I observe all 12 campaigns optimise for AddToCart. Separately: what is the end
goal event for this account — the event that means money?"

The wrong version anchors the client on the machine's guess. The right version puts the
observation on the table and lets the client define the truth. If the two conflict, that
conflict is a finding — often the most valuable one in the audit.

## The questions — asked in this order, never pre-answered

### Q1. Business model
"Which of these describes this account: service / lead generation, e-commerce, app,
local / store traffic, or something else?"
The client picks. Even when the account signals make it obvious, the client picks.

### Q2. The end goal
"What is the event that means money for this business — the thing everything upstream
exists to produce?" In their words. Do not offer candidates.

### Q3. The funnel — the client draws it
"Walk me through your full funnel, stage by stage, from first touch to the end goal.
Name each stage in your own words."

**Never present a template funnel and ask them to confirm it.** Two lead-gen businesses
have different funnels:

- A dental clinic: Lead → Qualified Lead → Appointment → **Visit → Treatment**
- An investment firm: Lead → Booked Meeting → **Completed Meeting → Client**

Same pillar, different shapes, different stage counts, different names — and the stages
a template would have merged or missed (Visit vs Treatment) are usually where the money
leaks. The reference funnels in `lead-generation.md` and `ecommerce.md` are **example
shapes for the auditor's understanding only**. They are never shown to the client as a
starting point and never used as a default.

### Q4. Per stage — where is it measured?
For every stage the client named: "Where does this stage live — Meta event, CRM field,
platform report, spreadsheet, or nowhere?" "Nowhere" is a legitimate answer and gets
recorded as a measurement gap, not treated as an error.

### Q5. Primary conversion vs end goal
"Which event should campaigns optimise toward?" — then, having already observed what
they *actually* optimise toward, surface any mismatch as a question:

"I observe every campaign currently optimises for AddToCart. You've said the end goal
is Purchase. Is optimising to AddToCart a deliberate choice — for example, for event
volume during learning — or is this the first time it's being looked at?"

Both answers are respectable. Deliberate → record the rationale in the contract.
Not deliberate → it becomes a candidate finding, **after** the contract is complete,
judged in the tracking phase where it belongs.

### Q6. Source of truth
"When Meta and your CRM / store / analytics disagree, which number wins?" One answer.
If the client says "it depends," push once for the default, and record the exceptions.

### Q7. Targets
"Do you have existing targets — CPL, CPA, ROAS, cost per [their end-goal stage]?
Where did they come from?" If none exist, record **none exist** — do not substitute an
industry median. Target derivation from unit economics is offered later, as an offer.

### Q8. Budget authority
"What is the authorised budget, and is it flexible?" Never assume redistribution beyond
the authorised amount is on the table.

### Q9. Compliance
"Any regulatory constraints — financial promotion rules, health claims, housing,
credit, employment?" Check Special Ad Category status as an observation alongside.

### Q10. Audit period
"What period should this audit cover?" Offer the trailing 90 days as a *suggestion
labelled as a suggestion*, not a default silently applied.

## The output — the Intake Contract

Write the answers into `01-Discover/Intake-Contract.md` (or present as a block when
running standalone), containing:

- Every declared truth, **in the client's own words** — their stage names are used in
  every later phase, table and report. If they say "Visit", no output ever says
  "Appointment Attended".
- Every observation that was on the table when they answered, so the record shows what
  they knew when they declared.
- The funnel as a stage table: client's stage name · measurement system · owner ·
  known gaps.
- The optimisation-event map: what each campaign group optimises toward, the declared
  end goal, and the client's stated rationale for any gap between them.
- A dated confirmation line: who confirmed, when.

## Gate condition

The gate is closed until Q1, Q2, Q3, Q5 and Q6 have client-given answers. Q4, Q7–Q10
may carry `Needs Confirmation` without blocking, but the report must say so.

**No hypothesis survives the gate.** If the client is unavailable and someone asks the
OS to proceed anyway, it proceeds in explicitly labelled *relative mode*: every
judgement marked as provisional against an unconfirmed contract, and the report's first
line says the contract was never confirmed.

## Re-running on a known account

**Check `meta-memory` before asking question one.** It searches Drive by account ID and
returns the stored contract if one exists.

If a contract exists, do not silently reuse it. Present it — "this is the contract from
14 May, confirmed by Ankit; has anything changed?" — and get a fresh confirmation line.
Funnels change, goals change, and a stale contract assumed current is just a hypothesis
with better formatting.

Walk only the changed items. A returning client should never be asked to redraw a funnel
they already drew. And treat a changed funnel, end goal or source of truth as a finding
in its own right — it usually breaks comparison with the prior period, which the report
must state rather than quietly compare across.
