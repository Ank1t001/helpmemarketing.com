---
name: meta-audit
description: "Run a phased, evidence-first Meta Ads account audit — eleven phases from business discovery through backend integrity, tracking validation, funnel mapping, structure, performance, audience, creative, landing pages and budget, to findings. Interactive by design: inspects evidence before asking, asks only what the current phase needs, audits one phase at a time, and never judges performance before tracking is validated. Use when the user asks to audit my Meta ads, audit my Facebook ads, first audit of a new account, take over an existing account, check my ad account health, review my paid social, or wants a full account review rather than a single check. Stage 2 of the HMM Meta Growth OS."
metadata:
  author: AnkitK
  brand: "HMM | helpmemarketing.com"
  version: "2.3.0"
  category: paid-social
---

# Meta Ads Account Audit

A phased audit that earns its conclusions. It inspects before it asks, asks before it assumes, and refuses to judge performance until it has verified that the numbers being judged are real.

This file controls the sequence, the evidence rules, the questions and the stopping conditions. The detailed checklists live in `references/`:

| File | Contains |
|------|----------|
| `meta-setup` *(sibling skill)* | Readiness check — Tier 1 connectors block, Tier 2 branches. Runs once per environment |
| `meta-memory` *(sibling skill)* | Account memory — looks the account up before Phase 1 asks anything, and saves the contract, findings and report as each gate closes |
| `references/intake-gate.md` | **Gate Zero — the Intake Contract.** The question script for Phase 1, the observation-vs-declaration rule, and the gate condition. Read this first, every run |
| `references/backend-tracking.md` | Full Phase 2 and Phase 3 checklists — Business Portfolio, ad account, connected assets, pixel/CAPI/events |
| `references/lead-generation.md` | The Service/Lead-Gen conditional path — tracking, funnel, forms, landing pages |
| `references/ecommerce.md` | The E-commerce conditional path — event chain, catalog, checkout, values |
| `references/audit-report-format.md` | Phase status blocks, finding format, evidence statuses, final report structure |

Read the reference for the current phase when you reach it — not all four upfront.

## What this audit never assumes

The business model. The primary goal. **The shape of the funnel.** What counts as a conversion. **That the optimisation event and the end goal are the same thing.** The source of truth. The correct KPI. Whether performance is good or bad. Whether a setting is intentional. That anything should be changed.

Every one of these is either verified from evidence, confirmed by the user, or labelled `Needs Confirmation`. There is no fourth option.

## Operating rules

1. Do not assume the business model, goals, funnel, KPIs, benchmarks or source of truth.
2. Audit **one phase at a time**. Complete the current phase before moving to the next.
3. **Inspect available evidence before asking the user a question.** If the account, website or connected tools can answer it, they answer it — then the user confirms the reading.
4. Ask only the questions the current phase needs. Never front-load a 30-question intake.
5. If information cannot be verified, label it `Needs Confirmation`. Missing information is not an error.
6. **Do not judge performance until tracking and measurement are validated** (Phase 3 gate).
7. Do not make changes to Meta, the website, CRM or any external system during the audit. This is read-only work.
8. Separate confirmed problems from suspected problems from opportunities — the statuses in `references/audit-report-format.md`.
9. Use the business's actual targets and historical data. Do not invent universal benchmarks. If the user wants external context, `meta-benchmarks` provides it with confidence marking — but it never substitutes for their targets.
10. **Pause when a blocker could make the remaining analysis unreliable.** A wrong pixel makes Phases 6–10 fiction; say so and stop.
11. When something looks wrong but might be deliberate, ask — "these three campaigns target the same location with the same event; are they intentionally separated for reporting or testing?" — rather than labelling it fragmentation.
12. Never ask for the total budget to be treated as flexible. Redistribution beyond the authorised budget requires an explicit question.

## The interaction loop

Run this loop for every phase:

```
Inspect the current phase's evidence
→ Record what is verified
→ Identify what is missing
→ Ask only the necessary questions
→ Wait for the answers
→ Complete the phase
→ Present the phase status block
→ Ask permission to continue
```

Do not collect every question at the start. Do not produce the whole audit in one response. The user sees each phase land, confirms or corrects it, and the next phase builds on confirmed ground.

## The phases

### Phase 0 — Readiness

On the first run in an environment, invoke `meta-setup`. Tier 1 — **Meta Ads connector and Google Drive** — is required and blocks; Tier 2 — CRM or commerce platform — is asked about and never blocks, but its absence is stated in outcome terms ("you will get cost per lead, not cost per closed deal, and those routinely disagree").

If the connector genuinely cannot be added, **Limited Mode** runs the audit from CSV exports with unverifiable items marked `Needs Confirmation` and a banner on the report. On later runs, `meta-memory` holds the capability record — confirm it rather than re-probing.

### Phase 1 — Gate Zero: the Intake Contract

**Before the first question, check memory.** If `meta-memory` is available, look the account up in Drive by its account ID. A stored contract means this is a returning account: present what is on file, ask what has changed, and walk only the changed items — never re-interview a client who already answered. No stored contract means a cold start and the full script below. Asking a returning client to redraw their funnel from scratch is the exact failure the memory layer exists to prevent.

Nothing else starts until this lands. Run the question script in `references/intake-gate.md` — the business model, the end goal, the funnel, the primary conversion, the source of truth, targets, budget authority, compliance and the audit period.

**The two-class rule governs this phase.** *Observable facts* (currency, events firing, what campaigns currently optimise toward) are read from the account and reported as observations. *Declared truths* (model, end goal, funnel shape, primary conversion, source of truth) are asked as **open questions and recorded verbatim** — never pre-filled from a hypothesis, never offered as "it looks like X, confirm?". An observation may sit next to a question; it may never become the question's suggested answer.

**The funnel is drawn by the client, stage by stage, in their own words.** Never present a template funnel for confirmation — two lead-gen businesses can have entirely different shapes (Lead → QL → Appointment → Visit → Treatment vs Lead → Booked Meeting → Completed Meeting → Client), and the stages a template would merge are usually where the money leaks. The chains in the conditional references are example shapes for the auditor's orientation only. The client's own stage names are used in every later phase, table and report.

**Surface optimisation-event mismatches as questions, not conclusions.** If every campaign optimises for AddToCart and the declared end goal is Purchase, put both facts on the table and ask whether the gap is deliberate. Record the answer in the contract; judge it later, in Phase 3, where it belongs.

**Phase 1 gate — closed until the client has given their own answers to:** business model, end goal, funnel, primary conversion, source of truth. The technical audit (Phases 2–3) may begin if performance *targets* are still unknown — but performance is not judged until they exist. If the client is unavailable, proceed only in explicitly labelled relative mode, with the unconfirmed contract stated on the report's first line.

**Output:** the Intake Contract — every declared truth verbatim, the funnel stage table, the optimisation-event map, and a dated confirmation line. On a repeat run, present the existing contract and re-confirm it; never silently reuse it. **Save it via `meta-memory` as the gate closes** — a dropped session should cost the analysis, never the interview. A changed funnel, end goal or source of truth is itself a finding: it usually invalidates period-over-period comparison, and the report must say so.

Once the model is confirmed, load the matching conditional reference — `references/lead-generation.md` or `references/ecommerce.md` — and carry it through every remaining phase.

### Phase 2 — Backend and account integrity

The first actual account inspection. Full checklist in `references/backend-tracking.md`: Business Portfolio (ownership, verification, security, people and partner access, former employees/agencies, system users, integrations), ad account (correct account, ID, currency, time zone, spending limit, billing status, payment failures, tax info, Account Quality, restrictions), connected assets (Page, Instagram, dataset/pixel, domain, catalog, app, Lead Access Manager, CRM integration, offline event source, custom audiences).

End with the phase status block and the question: **can the audit proceed safely?**

### Phase 3 — Tracking and data integrity

Only after the correct assets are confirmed. Full checklist in `references/backend-tracking.md`; the conditional path (lead vs purchase event chain) in the pillar reference. Perform or request a **test conversion** where possible.

**Phase 3 gate — pause the audit if:** the wrong pixel/dataset may be connected, events are duplicated, the primary conversion cannot be identified, purchase values are unreliable, CRM leads cannot be reconciled, or any tracking issue could invalidate performance analysis. State what is blocked and what remains auditable.

### Phase 4 — Funnel and measurement framework

Map the complete funnel before judging anything — **the funnel from the Intake Contract, in the client's own stage names**, never a template chain. The per-stage fields to fill (measurement system, event or CRM field, volume, rate, cost, data owner, known gaps) are in the pillar reference; the stage list itself came from the client in Phase 1. If a stage the client named has no measurement anywhere, that is a recorded gap, not a stage to silently drop. **This phase decides which KPIs Phase 6 is allowed to use.**

### Phase 5 — Account structure

Objectives, buying types, naming conventions, segmentation, funnel-stage / product / geographic separation, prospecting vs retargeting, testing vs scaling, duplicates and fragmentation, budget method, bid strategy, performance goal, optimisation event, attribution setting, placements, automated rules, Special Ad Categories, **Change History**. Ask before labelling anything fragmentation — rule 11.

### Phase 6 — Campaign performance

Only now. Current period, previous comparable period, 7/30/90-day trends, spend, results, cost per result, conversion rate, budget delivery, learning status, historical consistency, CRM outcomes, revenue or pipeline, conversion lag. **Judged against Phase 1's KPIs and Phase 4's framework only.** A low CPL is not automatically good; a high CPL is not automatically bad; the highest-CPL campaign may carry the lowest cost per qualified lead or per client.

### Phase 7 — Audience audit

Broad vs interest vs lookalike vs CRM audiences, retargeting, exclusions (including existing customers), overlap, geography, audience size, frequency, demographic and placement breakdowns, prospecting vs retargeting performance. **No exclusion recommendations from small samples.**

### Phase 8 — Creative audit

Concept, hook, offer, message, CTA, format, placement compatibility, copy, headline, visual hierarchy, brand consistency, compliance, fatigue, spend distribution, CTR, CPC, CPM, frequency, conversion rate, **cost per downstream business result**, comments and sentiment. Attribute the cause before the blame: creative problem vs audience problem vs offer problem vs landing-page problem vs tracking problem. Never blame creative because CPL is high.

### Phase 9 — Landing pages and forms

Landing pages: message match, mobile experience, speed, form functionality and length, CTA, trust, compliance, thank-you page, UTMs, conversion event, page conversion rate. Instant Forms: type, questions, qualification logic, privacy policy, review step, thank-you screen, CRM delivery, Lead Access permissions, duplicate/spam leads, form-to-qualified rate. Detail per pillar in the conditional reference.

### Phase 10 — Budget, bidding and delivery

Monthly budget vs actual spend, daily pacing, allocation across campaigns / products / funnel stages / testing / scaling, bid strategies and cost controls, budget-change history and learning resets, under- and over-delivery, spend concentration, budget spread across too many campaigns. **Ask before recommending redistribution beyond the authorised budget** — rule 12.

### Phase 11 — Final findings and recommendations

Assemble per `references/audit-report-format.md`. **Save the findings register and report via `meta-memory`**, and where a prior findings file exists, classify every finding as Resolved / Persisting / New / Regressed against it — a second audit's most valuable output is what changed, not what is. Every finding carries an evidence status; every recommendation carries finding, evidence, business impact, action, priority, confidence, dependencies, risk, **whether it resets learning**, and whether approval is required.

## Working with and without connectors

The Meta Ads connector is a Tier 1 requirement — see Phase 0. With it, inspect live: entities, field catalogue, custom conversions, datasets, activity log.

**Limited Mode** is the sanctioned exception for genuine no-access cases: CSV exports at campaign, ad set and ad level plus screenshots of Events Manager and Business Settings. Everything unevidenced by those is marked `Needs Confirmation`, and every report carries a Limited Mode banner. A Limited Mode audit is real and useful — a reader must simply never mistake it for a connected one. Absence of access is never a reason to estimate.

If account spend is too low to have produced ~50 conversions in the audit period, say so at Phase 4: Phases 6–8 would be judging noise. Offer to complete the technical phases (1–5, 9) and recommend a data-collection period for the rest.

---
*Built by Ankit kumar | HMM | helpmemarketing.com*
