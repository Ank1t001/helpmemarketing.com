---
name: meta-report
description: "Turn Meta Ads analysis into an audience-tuned report — founder one-pager, client report, or internal task summary — plus the recurring performance brief. Handles client-safe framing, benchmark calibration with confidence marking, and the HTML dashboard. Use when the user asks for a Meta ads report, client report, performance summary, monthly report, weekly brief, report this to my client, or wants findings written up for a specific audience. Stage 7 specialist in the HMM Meta Growth OS."
metadata:
  author: AnkitK
  brand: "HMM | helpmemarketing.com"
  version: "1.0.0"
  category: paid-social
---

# Meta Reporting

Formatting and calibration only. **Never introduce a new claim at reporting time** — everything here comes from vault notes written by earlier stages. If something belongs in the report and isn't in a note, the note is what's missing.

## Pick the audience first

| Audience | Wants | Structure |
|----------|-------|-----------|
| **Founder one-pager** | A decision | Score, 3 wins, 3 asks, one chart. One page. No methodology. |
| **Client report** | Confidence and evidence | Full narrative, before/after, what was done and why, what's next. Methodology in an appendix. |
| **Internal summary** | Task assignment | Item-level, owner and deadline per line. No narrative. |
| **Recurring brief** | Exceptions only | What changed, what broke, what needs a decision. Silence when nothing did. |

If the user hasn't said, infer from who they mention and ask only if genuinely ambiguous.

## The rule that separates a good report from a deck

**State the target before the number.** "CPL was $47" means nothing. "CPL was $47 against a $60 target derived from your $4,200 deal value and 22% close rate" is a finding. Every cost figure in the report carries the target it is being judged against and where that target came from.

If unit economics were unavailable, say so once, prominently, and mark every judgement as relative rather than absolute.

## Benchmarks

When citing an external benchmark, carry its confidence and its source. Published Meta benchmarks disagree with each other substantially — e-commerce ROAS figures in the 1.8–3.7× range circulate simultaneously for overlapping periods. Presenting one as fact is a credibility risk with any client who checks.

Prefer the account's own trailing 90 days as the benchmark wherever it exists. It holds constant every confound — margin, market, attribution window, seasonality — that makes external medians unreliable.

## Client-safe mode

Set `mode: "client"`. The limitations section retitles to "What sat outside this audit's scope" and reads as scope rather than absence. **The facts are identical — only the framing changes.**

Never delete a limitation to make a report look better. An agency that hides what it did not check gets found out by the one client who checks, and loses more than the limitation would have cost.

## What every report must contain

1. The score, its band, and what it is scored against
2. Exactly three headline findings — more and none of them land
3. What the top three fixes are worth, with effort stated. **A spend or revenue figure only if a data source measured it** — otherwise state it was not estimated and why
4. The coverage card: what was assessed, what was not, and why. Never empty
5. Roadmap items, each with a falsifiability check and a leading indicator the reader can watch without re-running the audit
6. Next steps by name

## The recurring brief

Different discipline entirely. Exceptions only. Structure: what changed / what broke / what needs a decision / what was suppressed as noise. If nothing happened, one line saying so. A brief that arrives every week saying "nothing to report" at length gets filtered within a month — and takes the real alert with it.

## Output

`REPORT.html` built from the Growth OS dashboard template — fill the JSON block, never edit markup or CSS — plus the markdown report for the chosen audience. Offer PDF conversion; deliver HTML if no converter exists.

## Hard rules

- Never introduce a claim not traceable to a vault note.
- Never present a cost figure without its target and the target's derivation.
- Never cite a benchmark without its confidence level.
- Never ship an empty limitations section.
- Never estimate a figure a data source failed to provide.

---
*Built by Ankit kumar | HMM | helpmemarketing.com*
