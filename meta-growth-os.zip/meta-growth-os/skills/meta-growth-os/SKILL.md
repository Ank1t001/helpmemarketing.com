---
name: meta-growth-os
description: "HMM Meta Growth OS — a staged framework that orchestrates the full Meta Ads skill library (audit, structure, audience, creative, signal, funnel, columns, benchmarks, drift, report) into one pipeline: Discover → Audit → Diagnose → Prioritize → Execute → Monitor → Report. Dual-pillar: Service & Lead Generation, and E-commerce. Every run builds an Obsidian-compatible vault of interlinked markdown notes. Use when the user says Meta growth OS, paid growth OS, run the Meta pipeline, full Meta Ads analysis, audit my Facebook ads, Meta Ads strategy end to end, scale my Meta Ads, or wants a complete paid social program rather than a single check. Also use when they ask 'where do I start with Meta Ads' for an account."
metadata:
  author: AnkitK
  brand: "HMM | helpmemarketing.com"
  version: "1.4.0"
  category: paid-social
---

# HMM Meta Growth OS

A staged operating system for Meta Ads. Each stage consumes the previous stage's artifact, invokes the right specialist skills, and writes its output as linked notes in an Obsidian-compatible vault. Run the whole pipeline or enter at any stage.

Everything in this OS resolves against one of two pillars. Establish the pillar in Stage 1 and carry it through every later stage — it changes the benchmarks, the funnel definition, the scoring weights and the decision rules.

| Pillar | You buy | You get paid on | The core problem |
|--------|---------|-----------------|------------------|
| **Service & Lead Generation** | A lead | A closed deal | The platform cannot see your real success metric unless you send it back |
| **E-commerce** | A purchase | Contribution margin | The platform sees the purchase but not the margin, the return, or the incrementality |

## Quick Reference

| Command | Stage | What it does |
|---------|-------|-------------|
| `setup` | 0 | Readiness check — what's connected, what it unlocks, what's blocked without it |
| `run <account>` | 0-7 | Discover → Report, then **stops** and offers Execute and Schedule. This is the default. |
| `discover <account>` | 1 | Pillar detection, business model, offer economics, market, competitors → Research Brief |
| `audit <account>` | 2 | Full account health check via the `meta-audit` skill (8 specialists) → Audit Report |
| `diagnose` | 3 | Pure synthesis: Broken / Missing / Leaking gap inventory (no new data pulled) |
| `prioritize` | 4 | Impact × Effort × Confidence × Time-to-Impact scoring → Quick Wins, Big Bets, 30/60/90 roadmap |
| `execute [item]` | 5 | Produce the fixes: creative briefs, structure plans, event specs, column presets |
| `monitor <account>` | 6 | Drift baseline + comparison, cost and delivery tracking, re-audit cadence |
| `report [audience]` | 7 | Stakeholder-ready report + the HTML dashboard |
| `schedule <account> [weekly\|monthly]` | 8 | Set it to re-run on its own and report only when something changed |
| `bench <pillar> [vertical]` | — | Fast path: benchmark lookup via `meta-benchmarks`, no audit, no vault stage |
| `columns` | — | Fast path: build the L1/L2/L3 column presets via `meta-columns` |
| `status` | — | Read the vault, show which stages are complete and what's next |

## Where a Run Stops

`run` goes Discover → Report and then **stops**. Execute and Schedule are opt-in.

Nobody wants an agent restructuring a live ad account in week one. Running ahead into Execute without being asked risks real money — a consolidated ad set resets learning, a paused campaign stops revenue. So at the end of Stage 7, present what was found and offer the next two steps by name — then wait.

Run Execute or Schedule when the user asks for them, or when they explicitly say "run everything". **Even then, every account-mutating action is draft-first and paused-first** — see Orchestration Rule 6.

## The Deliverable

Two layers, and they serve different readers:

1. **The dashboard** — one self-contained HTML file, `{account}-meta-os/REPORT.html`. This is what the human opens, reads, screenshots and sends to a client. Build it from `assets/dashboard-template.html` — see the Data Contract below.
2. **The vault** — the working record. Traceable, linked, resumable. This is what makes the run repeatable and what later stages read from.

Build the dashboard at the end of every `run` and every `report`. Never make the user open a folder of markdown to find out what you found.

## The Vault

All outputs live in one Obsidian-compatible vault: `{account}-meta-os/`. Plain markdown with `[[wikilinks]]` and YAML properties, so it opens as a connected graph in Obsidian and reads fine anywhere else.

```
{account}-meta-os/
├── 00-Dashboard.md            ← health score, pillar, stage status, links to every note
├── 01-Discover/Research-Brief.md
├── 02-Audit/Audit-Report.md, Findings/*.md (one note per category)
├── 03-Diagnose/Gap-Inventory.md
├── 04-Prioritize/Roadmap.md
├── 05-Execute/Creative-Briefs/*.md, Structure/*.md, Events/*.md, Presets/*.md
├── 06-Monitor/Baseline.md, Drift-Log.md
├── 07-Report/<audience>-Report.md
├── 08-Schedule/Schedule-Receipt.md
└── REPORT.html                ← the deliverable, built from assets/dashboard-template.html
```

Vault rules:
- Every note starts with YAML properties: `stage`, `date`, `pillar`, `status: draft|final`, and `score` where applicable — so Obsidian Dataview/Bases queries work.
- Every finding, gap, and roadmap item gets a stable ID (`GAP-014`, `REC-007`) and links back to its source note with a wikilink: a roadmap item links to its gap, the gap links to the audit finding it came from. Full traceability, both directions.
- After completing any stage, update `00-Dashboard.md`: stage checklist, current health score, top 3 next actions.
- If the vault already exists for an account, resume — never overwrite prior stage notes; append dated entries instead.
- **Never write raw lead data, customer PII, or full email/phone lists into the vault.** Aggregate counts and rates only.

## Stage Definitions

### Stage 0 — Readiness (first run in an environment)

**Skills:** `meta-setup`.
**Do:** before Stage 1 asks anything, confirm the OS can actually do the job. Tier 1 — the **Meta Ads connector** and **Google Drive** — is required and **blocks**: without the connector there is no account to read, and without Drive there is no memory, so every run would re-interview the client from scratch. Tier 2 — CRM (Service) or commerce platform (E-commerce) — never blocks, but must be asked about and its absence stated in outcome terms.

Detect by **capability, not by connector name** — names drift and contain typos, and a check written against an expected name reports failures against working connectors.

**When Tier 1 is missing:** name the connector, say where to add it, and wait. On "I've connected it", **re-probe and confirm** — never accept the claim as evidence. If the user genuinely cannot connect (no API access, IT restriction, a prospect's account being audited pre-sales), offer **Limited Mode**: a CSV-based audit with unverifiable items marked `Needs Confirmation` and a Limited Mode banner on every report. Drive remains required even in Limited Mode.

**On later runs:** `meta-memory` holds the confirmed capability record — present it (*"last run used the Meta connector, Drive and HubSpot exports; same setup?"*) instead of re-probing.

**Output:** the readiness table, and the capability record saved to the account folder.
**Gate:** Tier 1 satisfied, or Limited Mode explicitly accepted.

### Stage 1 — Discover
**Skills:** `meta-memory` (**look the account up before asking anything**), `meta-benchmarks` (pillar definitions and target-setting), `meta-signal` (what is actually being tracked), and the Intake Contract question script in `meta-audit/references/intake-gate.md` — **the entry gate for the whole OS.**
**Memory first.** Before the first question, `meta-memory` searches Drive for the account ID. Found: present the stored contract, ask what changed, walk only the deltas. Not found: cold start, full intake. Either way the contract is saved as the gate closes, so a dropped session costs the analysis and never the interview.
**The two-class rule.** Observable facts (currency, events firing, what campaigns currently optimise toward) are read from the account and reported as observations. Declared truths — the pillar, the end goal, **the funnel shape**, the primary conversion, the source of truth — are asked as open questions and recorded verbatim. Never pre-fill a declared truth from a hypothesis; an observation may sit beside a question but never becomes its suggested answer. **The funnel is drawn by the client stage by stage in their own words** — template chains are auditor orientation only, and the client's stage names are used in every later stage, table and report.
**Do:** put the account observations on the table, then run the intake questions. If what campaigns optimise toward differs from the declared end goal (all ad sets on AddToCart, goal is Purchase), surface both facts and ask whether the gap is deliberate — record the answer, judge it in Stage 2 where it belongs. Then capture the economics the whole OS depends on:
- **Service:** average deal value, gross margin, lead→qualified→appointment→close rates, sales cycle length, and the current cost-per-closed-deal if known.
- **E-commerce:** AOV, contribution margin after COGS/shipping/fees/returns, repeat rate, and target payback window.

Identify market and currency, the attribution setting in use, and 3–5 competitors (ask the user to confirm competitors before proceeding).
**Output:** `01-Discover/Research-Brief.md` — pillar, business profile, unit economics, derived target CPA/CPL/ROAS, market context, competitor list — plus `01-Discover/Intake-Contract.md`: every declared truth verbatim, the client-drawn funnel stage table, the optimisation-event map, and a dated confirmation line.
**Gate:** the Intake Contract is closed until the client has given their own answers to pillar, end goal, funnel, primary conversion and source of truth — and confirms the unit economics. **Do not proceed without the economics** — every target in this OS is derived from them, and an audit scored against an invented target is worthless. On a repeat run against an existing vault, present the prior contract and re-confirm it; never silently reuse it.

### Stage 2 — Audit
**Skills:** `meta-audit` — an eleven-phase, evidence-first interactive audit — drawing on `meta-structure`, `meta-audience`, `meta-creative`, `meta-signal`, `meta-funnel`, `meta-columns` for specialist depth.
**Data engine:** if a Meta Ads MCP connector is available, pull live account data — campaign/ad set/ad entities, field catalogue, custom conversions, datasets, activity log. Otherwise ask for CSV exports at all three levels plus Events Manager and Business Settings screenshots, and mark unevidenced items `Needs Confirmation`.
**Do:** run `meta-audit`'s phases in order — business understanding, backend integrity, tracking validation, funnel mapping, structure, performance, audience, creative, landing pages, budget, findings. One phase at a time: inspect evidence, ask only what that phase needs, present the phase status block, ask permission to continue. Segment every cost metric by pillar-relevant split before averaging — form type for Service, prospecting vs retargeting for E-commerce. **A blended account average hides the thing you are looking for.** Write each phase's findings as its own note under `02-Audit/Findings/` with an evidence status per finding.
**Output:** `02-Audit/Audit-Report.md` with Account Health Score (0-100) using the weights below; findings notes linked from it.
**Gates (internal to the audit):** Phase 1 — business model, primary goal, primary conversion and source of truth confirmed by the user before anything is judged. Phase 3 — the audit pauses if tracking issues would make performance analysis unreliable (wrong pixel, duplicated events, unidentifiable primary conversion, irreconcilable CRM). **Performance is never judged before tracking is validated.**

### Stage 3 — Diagnose
**Skills:** none — pure synthesis. Pull no new data; work only from Stage 1-2 notes.
**Do:** classify every audit finding plus every economics-vs-reality mismatch into three buckets:
- **Broken** — exists but wrong (pixel double-firing, rejected ads, wrong optimisation event, Learning Limited ad sets)
- **Missing** — should exist but doesn't (no CAPI, no offline conversion upload, no creative testing structure, no exclusion of converters)
- **Leaking** — works but underperforms (a campaign at 3× median cost per result, 40% no-show rate, 50% of clicks never reaching the landing page)

Collapse findings that share a root cause into a single gap — fourteen ad sets stuck in Learning Limited because the account is over-segmented is one gap, not fourteen. What matters downstream is the number of causes, not the number of symptoms.
**Output:** `03-Diagnose/Gap-Inventory.md` — every gap has an ID, bucket, evidence link (`[[Audit-Report#...]]`), and estimated spend-at-risk.
**Gate:** none.

### Stage 4 — Prioritize
**Skills:** none — scoring framework.
**Do:** score every gap: **Impact** (spend at risk or upside, 1-5) × **Effort** (inverse, 1-5) × **Confidence** (evidence strength, 1-5) × **Time-to-Impact** (inverse, 1-5). Sort into **Quick Wins** (high impact, low effort), **Big Bets** (high impact, high effort), **Kill/Defer** (low impact). Sequence dependencies — a conversion-event fix that changes what the algorithm optimises toward comes before any creative work measured against it.

Rank against the Leverage Ladder, not by how easy something is to click:

| Rank | Lever | Why it ranks here |
|------|-------|-------------------|
| 1 | Offer | Nothing in an ad account beats a better offer |
| 2 | Creative concept | The spread between best and worst creative usually dwarfs the spread between audiences |
| 3 | Qualification (Service) / Checkout friction (E-comm) | Changes what the algorithm optimises toward, or compounds across every campaign at once |
| 4 | Landing page | Fixes conversion for all traffic simultaneously |
| 5 | Conversion event / performance goal | Optimising to a truer event beats optimising to a cheap proxy, if volume supports it |
| 6 | Budget allocation | Free money when the best-to-worst spread is wide |
| 7 | Audience / targeting | Broad + strong creative now beats granular targeting in most accounts |
| 8 | Placement exclusions | Worth doing once, rarely worth revisiting |
| 9 | Bid strategy / caps | A throttle. Fixes nothing broken upstream |

**Output:** `04-Prioritize/Roadmap.md` — ranked table + 30/60/90-day plan; every item links to its gap.
**Gate:** user approves the roadmap before execution.

### Stage 5 — Execute
**Skills:** `meta-creative` (creative briefs and testing structure), `meta-structure` (consolidation and campaign architecture plans), `meta-signal` (event specs, CAPI and offline conversion mappings), `meta-columns` (column presets and custom metrics), `meta-funnel` (landing page and post-click fixes).
**Do:** work the roadmap top-down, or the specific item the user names. Every deliverable is draft-first — nothing is presented as ready-to-publish without flagging what a human must verify (claims, compliance, budgets, audiences).
**Account changes are paused-first and never bulk.** Build campaigns and ad sets in a paused state for human review. Never resume, never raise a budget, never pause a live spending campaign without explicit per-item confirmation.
**Output:** deliverable notes under `05-Execute/`, each linking back to its roadmap item and marked `status: draft` until the user approves.
**Gate:** user reviews each deliverable, and separately confirms any live account mutation.

### Stage 6 — Monitor
**Skills:** `meta-drift` (baseline + compare), `meta-report` (recurring performance brief), `meta-memory` (prior findings to diff against).
**Do:** capture a drift baseline after fixes ship; on subsequent runs, compare and log regressions; track the leading indicators attached to each executed item (e.g. "Delivery sub-status on the consolidated ad set" — something the user can check without a full re-audit). The two monitoring modes answer different questions: drift answers "did anything break?", the recurring brief answers "how are we trending?" Run drift after any structural change, the brief on a recurring cadence.
**Watch the judgement window.** Do not log a regression inside the learning phase or below ~50 conversions — that is noise, and logging it trains the user to react to noise.
**Output:** `06-Monitor/Baseline.md`, dated entries in `06-Monitor/Drift-Log.md`. Recommend re-audit cadence (monthly for active programs, quarterly for maintenance).
**Gate:** none.

### Stage 7 — Report
**Skills:** `meta-report` — formatting and calibration.
**Do:** ask which audience (or infer): **founder one-pager** (score, 3 wins, 3 asks, one chart), **client report** (full narrative with before/after evidence), **internal summary** (task-level, owner-and-deadline oriented). Pull only from vault notes — never introduce new claims at reporting time.
**Output:** `{account}-meta-os/REPORT.html` (the dashboard — always) plus `07-Report/<audience>-Report.md`. Offer PDF conversion of the dashboard via weasyprint, wkhtmltopdf or headless Chromium; deliver the HTML if no converter exists.
**Then stop.** Present the findings and offer Execute and Schedule by name.
**Gate:** none.

### Stage 8 — Schedule
**Skills:** `meta-drift` and `meta-report` are what the scheduled run invokes.
**Do:** set the pipeline to re-run on its own.

1. **Confirm cadence.** Default **weekly** for an active programme (spend is moving, creative is shipping), **monthly** for maintenance. Ask which applies rather than assuming.
2. **Compose a standalone prompt.** A scheduled run starts cold — no memory of this conversation, no idea which account, no vault path. The prompt must carry the ad account ID, the pillar, the derived targets, the vault location, which stages to re-run (Audit and Diagnose), and what to report. A prompt that says "re-run the audit" produces an empty brief every week forever.
3. **Create the task** using whatever scheduling the environment offers.
4. **Set the notification rule:** report only when something changed, broke, or crossed a threshold. A silent week is a good week. A brief that arrives every Monday saying "nothing happened" gets filtered inside a month, and then the real alert gets filtered with it.
5. **Write the schedule receipt** — task name, cadence, next run, and the exact prompt used — so the user can audit or cancel it later.

**If no scheduling mechanism is available:** say so plainly, then output the standalone prompt as text with instructions to paste it into whatever they do have.

**Output:** `08-Schedule/Schedule-Receipt.md`.
**Gate:** user confirms cadence before the task is created.

## The Reasoning Layer (optional)

If the `ankit-logic` skill is available in this session, load it and use it at exactly two points. If it is not available, produce clean neutral output and say nothing about it — the analysis stands on its own without a voice layer.

**Stage 4, while prioritising.** Its models sharpen the ranking itself, not just the prose. Unlike the SEO OS, most of its models are paid-media models and will fire here — use them on the ranking, not as decoration.

**Stage 7, once, after the roadmap.** Add a single "If Ankit were in your seat" beat — 2-4 sentences — placed where the reader is deciding what to actually do. Populate it into the dashboard's `beat` field.

Rules that keep it from becoming decoration:
- **One beat per report.** Not one per section, not one per roadmap group. One.
- **Only when a model genuinely fits.** If none fits, omit the beat entirely.
- **It corrects a thinking error**, it does not summarise. If the beat restates the roadmap, delete it.
- **It appears in client mode too.** A client reading it is getting the judgment they paid for.
- Never invent framework internals. Name the framework, point to the guide.

`ankit-logic` is deliberately **not** bundled with this plugin. Downloads produce professional, voiceless output; runs with the layer installed carry the reasoning.

## Dashboard Data Contract

`assets/dashboard-template.html` is a finished, styled document. It renders itself from a single JSON block with `id="run"`. **Fill that JSON. Never edit the markup or CSS** — that is what keeps every run visually identical and on-brand.

Copy the template to `{account}-meta-os/REPORT.html`, replace the JSON, done.

| Field | Contents |
|-------|----------|
| `account`, `accountId`, `date`, `currency` | Identity of the run |
| `mode` | `internal` (full limitation detail) or `client` (same facts, framed as scope) |
| `pillar` | `service` or `ecommerce` — drives every benchmark comparison in the render |
| `businessType` | What Stage 1 detected, in words |
| `economics` | `{metric, value, source}[]` — deal value / AOV, margin, close rate, derived target. **The audit is scored against these.** |
| `healthScore` | 0-100, or `null` if too little could be assessed to score honestly |
| `headline` | Exactly 3 findings: `{severity, title, note}`. These carry the share card. |
| `topThreeValue` | What the top three fixes are worth. State effort and what they unblock. Give a spend or revenue figure **only** if account data measured it — otherwise say it was not estimated and why. |
| `coverage` | `spendAnalysed`, `dateRange`, `assessed[]`, `notAssessed[{category, reason}]`, `sources[{name, connected}]` |
| `stages` | Eight entries: `{n, name, kind:"you"\|"method", produced}`. Stages not run say so. |
| `categories` | Eight: `{name, weight, score, specialist, notAssessed?}`. `score: null` where unassessed. |
| `benchmarks` | `{metric, account, benchmark, source, confidence:"high"\|"medium"\|"low", verdict}[]` — never show a benchmark without its confidence |
| `gaps` | `{id, bucket:"Broken"\|"Missing"\|"Leaking", title, evidence, spendAtRisk}` |
| `roadmap` | `quickWins[]`, `bigBets[]`, `killDefer[]` — each `{id, gap, title, lever, impact, effort, confidence, time, score, falsifiable, indicator}` |
| `plan` | `{"30":[], "60":[], "90":[]}` |
| `checklist` | `{id, text}` — the sign-off gates |
| `couldNotCheck` | `{item, why}` — every limitation. Never ship this empty; if everything was assessed, say that explicitly. |
| `beat` | Optional. `{title, body}` — the reasoning-layer beat, rendered after the roadmap. Omit the field entirely when `ankit-logic` is unavailable or no model fits. |
| `nextSteps` | `{title, what, cmd}` — Execute, Schedule, and the highest-value connector to add |

**Client-safe mode.** Set `mode: "client"` and the limitations section retitles to "What sat outside this audit's scope" and reads as scope rather than absence. The facts are identical — only the framing changes. Never delete a limitation to make a report look better.

## Optional Enrichment

These need an API key, MCP server or data export. When present they deepen a stage; when absent the stage proceeds and marks itself partial. Their absence is never a reason to estimate.

| Source | Stage | Adds |
|--------|-------|------|
| Meta Ads MCP connector | 1, 2, 5, 6 | Live entity data, field catalogue, custom conversions, datasets, creative previews, campaign creation |
| CRM (HubSpot, Salesforce, Pipedrive) | 1, 2, 6 | **Service pillar: the entire L4 layer.** Lead→close rates, no-show rate, deal value |
| Shopify / commerce platform | 1, 2, 6 | **E-comm pillar: true revenue, margin, returns, repeat rate** — the denominators platform ROAS cannot see |
| GA4 | 2, 6 | Independent cross-check on platform-reported conversions |
| Meta Ad Library | 1 | Competitor creative and messaging |
| Apify / scraping | 1 | Competitor creative at scale across platforms |
| Higgsfield or equivalent | 5 | Creative production for the briefs Stage 5 writes |
| Scheduling mechanism | 8 | Recurring runs; absent, the standalone prompt is handed over |

**The two that never get substituted** are the CRM (Service) and the commerce platform (E-commerce). Every other source describes what the ad platform already thinks; these two describe what actually happened. An account run without one of them is optimising a proxy, and the report must say so on the coverage card.

## Orchestration Rules

1. **Check skill availability first.** Delegate only to skills present in the available-skills list. If a specialist is missing, run that stage's work inline at reduced depth and note it in the stage note's properties (`coverage: partial`).
2. **Stages read artifacts, not memories.** Each stage starts by reading the previous stage's notes from the vault — this keeps runs resumable across sessions.
3. **Entering mid-pipeline:** if a required upstream artifact is missing (e.g. `diagnose` with no audit), tell the user and offer to run the missing stage first — don't improvise the missing input.
4. **Match scope to the ask.** A benchmark question routes to `bench`, a column question to `columns`. Reserve `run` for genuinely account-wide programs.
5. **Every recommendation carries four things:** the observation it rests on, its dependency relationship to other recommendations, a falsifiability check ("how would we know this failed?"), and a leading indicator the user can monitor without re-running the audit.
6. **Nothing goes live without a human.** Draft-first, paused-first, one item at a time. No bulk pauses, no budget changes, no audience edits without explicit per-item confirmation. This is real money and edits reset learning.
7. **Stop at Report unless asked.** Execute and Schedule are offered, not assumed.
8. **The dashboard is the deliverable.** Every `run` and `report` ends with `REPORT.html` built from the template.
9. **Use the reasoning layer when present.** Load `ankit-logic` if available; degrade silently to neutral output if not.
10. **Never fabricate data.** If a data source is unavailable, the dependent analysis is skipped and marked partial — not estimated.
11. **Segment before you average.** Never report a blended cost metric across form types (Service) or across prospecting and retargeting (E-commerce). The blend is where the truth goes to hide.

## Scoring Methodology

### Meta Account Health Score (0-100)

| Category | Weight | Specialist |
|----------|--------|-----------|
| Signal & Tracking | 20% | `meta-signal` |
| Creative | 18% | `meta-creative` |
| Account Structure | 16% | `meta-structure` |
| Funnel & Post-Click | 14% | `meta-funnel` |
| Audience & Targeting | 12% | `meta-audience` |
| Measurement & Reporting | 10% | `meta-columns` |
| Budget & Pacing | 6% | `meta-structure` |
| Delivery & Compliance Health | 4% | `meta-audit` |

`meta-setup` and `meta-memory` carry no weight — they are infrastructure, not categories. Setup runs before Stage 1 on a new environment; memory runs before Stage 1 and after each gate.

**Signal & Tracking carries the heaviest weight on purpose.** Everything downstream inherits its quality. An account with perfect creative optimising toward a mis-fired event is spending efficiently in the wrong direction, and no amount of creative testing will surface that. This is the inverse of the SEO OS, where content quality leads — in paid, measurement leads.

Unassessable categories redistribute their weight proportionally; state this in the dashboard.

### Priority Levels

- **Critical**: money is actively being wasted or lost (immediate — same day)
- **High**: significant efficiency drag (within 1 week)
- **Medium**: optimization opportunity (within 1 month)
- **Low**: nice to have (backlog)

## Quality Gates (hard rules, all stages)

- **Never optimise to cost per lead alone on the Service pillar.** Every lead-cost recommendation must reference a down-funnel rate or explicitly flag that none was available.
- **Never optimise to ROAS alone on the E-commerce pillar.** Break-even ROAS = 1 ÷ contribution margin. State it before recommending any ROAS target.
- **Never compare across objectives.** Lead-objective and traffic-objective CPCs differ by ~2.7×; comparing them is a category error, not an insight.
- **Never compare across attribution windows.** Flag mixed windows in an account as a finding, not a footnote.
- **Never compare cold and warm creative metrics.** Retargeting hook rate runs 30-45% against cold's 18-28% and is not a creative-quality signal.
- **Never declare a winner below ~50 conversions or inside the learning phase.** Return `WAIT`.
- **Never recommend a change that resets learning without saying so** and estimating the cost of the reset.
- **Never write customer PII into the vault.**
- **Regulated verticals** (finance, health, housing, employment, credit) — check Special Ad Category status before recommending any targeting change. Getting this wrong is an account-level risk, not a performance one.

## Error Handling

| Scenario | Action |
|----------|--------|
| Unrecognized command | List the Quick Reference table; suggest the closest match. |
| No account access | Ask for CSV exports at campaign, ad set and ad level; state which checks become impossible. |
| Specialist skill fails mid-stage | Keep partial results, note which specialist failed in the stage note, continue the pipeline. |
| Ambiguous pillar | Present both with the signals detected; ask the user to confirm. Never guess — the whole OS branches on it. |
| Unit economics unavailable | **Stop at Stage 1.** Offer to proceed with platform-only targets, stating plainly that every score will be relative rather than absolute. |
| Vault exists with conflicting account data | Ask whether to resume the existing vault or start a fresh dated one — never silently overwrite. |
| Optional data source missing | Skip dependent checks, mark `coverage: partial`, never estimate the missing numbers. |
| Account spend too low to analyse | Say so. Below roughly 50 conversions in the window there is nothing to diagnose; recommend a data-collection period instead of a fake audit. |

---

*Built by Ankit kumar | HMM | helpmemarketing.com*
*For performance marketers and brand owners who want to think like Growth Architects, not media buyers.*
