---
name: meta-setup
description: "Readiness check and connection setup for the Meta Growth OS. Probes which connectors are available, reports what each one unlocks and what is blocked without it, guides the user to connect what is missing, and saves the confirmed setup so later runs skip the check. Use when the user says set up meta growth os, configure meta os, what connections do I need, check my setup, why can't it see my account, or is my Meta connector working — and automatically on the first run of meta-growth-os or meta-audit against a new environment."
metadata:
  author: AnkitK
  brand: "HMM | helpmemarketing.com"
  version: "1.0.0"
  category: paid-social
---

# Meta Growth OS — Setup & Readiness

Runs once per environment, and again whenever something looks missing. Its job is to make sure nobody starts an audit that cannot produce a real answer — and to make the fix obvious when something is absent.

`references/connectors.md` carries the detection patterns and the current connector names. Read it before probing.

## The two tiers

| Tier | What | Behaviour when missing |
|------|------|------------------------|
| **1 — Required** | Meta Ads connector · Google Drive | **Blocks.** Name the fix, offer Limited Mode, wait |
| **2 — Down-funnel** | CRM (Service) · Commerce platform (E-commerce) | Ask which they use, accept a connector **or** an export. Never blocks |

Tier 1 is required because without the Meta connector there is no account to audit, and without Drive there is no memory — every run would re-interview the client from scratch, which is the failure the OS exists to prevent.

Tier 2 never blocks because almost nobody has a CRM MCP, and an export works nearly as well. What Tier 2 must never do is stay silent: an audit with no down-funnel data can only judge cost-per-proxy, and the user has to know that before they read a single number.

## How to probe

**Detect by capability, never by exact name.** Connector names are not standardised and are frequently misspelled — one real registry entry reads `Meta_Coonector`. A check hard-coded to a name will report "not connected" against a working connector, which is worse than not checking at all.

Ask instead: *can I see any tool that reads ad account entities?* *Any tool that creates files in Drive?* Then confirm the reading with the user rather than asserting it. If the environment offers a tool-discovery mechanism for deferred tools, use it before concluding something is absent — a tool that has not loaded yet is not a tool that is missing.

## The readiness report

Present one table, then act on it:

```
Meta Growth OS — readiness

  Meta Ads connector      ✓ connected        (12 ad accounts visible)
  Google Drive            ✓ connected        (memory folder ready)
  CRM                     ✗ not detected     ← down-funnel unavailable
  Commerce platform       — not needed       (Service pillar)

Tier 1 satisfied. Down-funnel analysis will be marked unavailable —
lead-to-close, no-show and bad-lead rates cannot be measured.

Continue, or set up the CRM path first?
```

State what each gap costs in outcome terms, not feature terms. "Down-funnel unavailable" means little; "you will get cost per lead but not cost per closed deal, and those routinely disagree" means something.

## When Tier 1 is missing

Name the connector and where to add it, then **wait**. Do not proceed, and do not re-probe on a loop.

> The Meta Ads connector isn't visible in this session. Add it in your client's connector settings, then say "check again" and I'll re-probe before we start.

When the user says they have connected it, **re-probe and confirm** before continuing. Never take "done" as evidence — a false start produces an audit built on nothing, and the user only finds out at Phase 6.

If they say they cannot connect it — no API access, IT restriction, a prospect's account they are auditing pre-sales — offer Limited Mode.

## Limited Mode (CSV audit)

The escape hatch for genuine no-access cases. Offered, never defaulted to.

> **Limited Mode** — I can audit from CSV exports instead.
> Export from Ads Manager at campaign, ad set and ad level for your chosen period, plus screenshots of Events Manager and Business Settings.
>
> What still works: structure, creative ratios, budget and pacing, benchmark comparison, the full roadmap.
> What cannot be verified: live event integrity, dataset health, custom conversion rules, activity log, Special Ad Category status.
> Everything unverifiable is marked `Needs Confirmation`, and the report carries a Limited Mode banner.

Drive is still required in Limited Mode. Memory is what makes the second audit worth more than the first.

Every report produced this way carries the banner on page one. A Limited Mode audit is a real, useful audit — but a reader must never mistake it for a connected one.

## Tier 2 — ask, then branch

Do not guess how their data is reachable. Ask:

**Service pillar:** *"Where does your lead outcome data live — HubSpot, Salesforce, Pipedrive, GoHighLevel, Zoho, a spreadsheet, or somewhere else?"*
**E-commerce pillar:** *"Where does your order and returns data live — Shopify, WooCommerce, BigCommerce, or somewhere else?"*

Then branch on the answer:

| Answer | Path |
|---|---|
| A platform with a connector present | Use it |
| A platform with no connector present | Request an export — name the exact fields needed |
| A spreadsheet | Request it directly |
| "We don't track that" | **This is itself a finding.** Record it, proceed, and make it prominent in the report |

"We don't track that" is the most common answer on the Service pillar and the most important one. It is not a setup failure — it is the top gap in the account, and the audit should say so.

## Save the result

Once confirmed, hand the capability record to `meta-memory` for the account folder: which connectors were present, which were confirmed absent, the Tier 2 route chosen, whether Limited Mode was used, and the date.

On the next run, present it rather than re-probing: *"Last run used the Meta connector, Drive, and HubSpot exports. Same setup?"* One question instead of a full readiness pass.

## Standalone use

- *"What connections do I need?"* → the tier table with what each unlocks
- *"Check my setup"* → probe and report
- *"Why can't it see my account?"* → probe, and check ad-account-level access, not just connector presence
- *"Set up the CRM path"* → Tier 2 branch only

## Hard rules

1. **Never claim a connector is present without evidence.** Confirm the reading with the user.
2. **Never proceed past a Tier 1 gap** except into explicitly labelled Limited Mode.
3. **Never treat "I connected it" as confirmation** — re-probe.
4. **Never let a Tier 2 gap pass silently.** State what it costs, in outcome terms.
5. **Never guess the CRM or commerce platform.** Ask.
6. **Detect by capability, not by name.** Names drift and contain typos.
7. **Never suggest connecting anything containing customer PII** beyond what the audit needs — aggregate rates and counts, never lead lists.

---
*Built by Ankit kumar | HMM | helpmemarketing.com*
