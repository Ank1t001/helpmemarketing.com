# Connector Detection Reference

How to work out what is actually available, without depending on names that drift.

---

## The naming problem

Connector registry names are not standardised. The same Meta connector appears under
different names in different environments, and they are not always spelled correctly —
one real registry entry reads **`Meta_Coonector`**. A readiness check written against an
expected name will report "not connected" against a working connector, send the user off
to fix something that is not broken, and lose their trust in the first two minutes.

**Detect by capability. Confirm with the user. Never assert from a name.**

## Capability probes

| Capability needed | What to look for | Confirms |
|---|---|---|
| Ad account entity read | Any tool that lists ad accounts, campaigns, ad sets or ads | Meta connector |
| Ad account metadata | Any tool returning account currency, status or spending limits | Meta connector depth |
| Drive file create | Any tool that creates a file or folder in Google Drive | Memory writes |
| Drive search / read | Any tool that searches Drive by title or reads file content | Memory reads |
| CRM record read | Any tool reading deals, contacts, opportunities or pipeline stages | Down-funnel, Service |
| Commerce order read | Any tool reading orders, products, refunds or customers | Down-funnel, E-commerce |

If the environment exposes deferred or lazily-loaded tools, search for them before
concluding anything is missing. **A tool that has not loaded is not a tool that is absent** —
this is the single most common false negative.

## Confirm before concluding

Presence of a tool is not proof of working access. A Meta connector can be installed and
still return nothing because the user has no permission on the ad account in question.

So the probe has two steps: *can I see the capability*, then *does it return data for this
account*. Listing the ad accounts is the cheapest real test — it either returns accounts or
it does not, and the failure message usually names the reason.

Same for Drive: creating the root memory folder is the test. If it succeeds, Drive works.

## Known connector families

Names current as of August 2026 and expected to change. Treat as a starting point for
recognition, never as a required match.

**Meta ads** — official Meta Ads connectors, and third-party wrappers. Look for ad account,
campaign, ad set, ad, insights and dataset operations.

**Google Drive** — official Google Drive connector. Look for create, search, read and
metadata operations on files. Note that Drive connectors commonly **cannot update file
content**, only title and location — see `meta-memory/references/drive-mechanics.md`.

**CRM** — HubSpot, Salesforce, Pipedrive, Zoho, GoHighLevel, Attio, Close. Most users will
have none of these connected; exports are the normal path.

**Commerce** — Shopify, WooCommerce, BigCommerce, Stripe (for payments and refunds rather
than catalog). Shopify is the most commonly connected of these.

## What to request when a connector is absent

Name the exact fields, not "an export" — a vague request produces a file missing the one
column that mattered.

**Meta, Limited Mode:** Ads Manager exports at campaign, ad set and ad level covering the
audit period, using the `Ankit L1/L2/L3` column presets if available. Plus screenshots of
Events Manager (datasets, events, match quality) and Business Settings (people, partners,
assets).

**CRM export, Service pillar:** one row per lead, with — lead created date · source or
campaign identifier (UTM or Meta campaign name) · current stage · stage-change dates ·
qualified yes/no · appointment booked yes/no · appointment attended yes/no · closed
won/lost · deal value. **Names, emails and phone numbers must be stripped before sending.**

**Commerce export, E-commerce pillar:** one row per order, with — order date · order value ·
discount · shipping · source or campaign identifier · new vs returning customer flag ·
refunded yes/no · refund value · product category. **No customer names or addresses.**

## Privacy

The audit needs rates and counts, never identities. Every export request must say so
explicitly, and any file arriving with PII in it should prompt a note back to the user
rather than silent use. This matters more when the pack is shared publicly — the person
running it may not have thought about what they are about to upload.
