---
name: meta-signal
description: "Audit and fix Meta Ads tracking, conversion events and signal quality — pixel and Conversions API setup, event deduplication, custom conversions, offline conversion uploads, event match quality, attribution settings and optimisation-event choice. Use when the user asks about pixel setup, CAPI, conversions API, event tracking, event match quality, custom conversions, offline conversions, attribution window, which event should I optimise for, my conversions look wrong, or Meta numbers don't match my CRM/Shopify. Highest-weighted category in the HMM Meta Growth OS."
metadata:
  author: AnkitK
  brand: "HMM | helpmemarketing.com"
  version: "1.0.0"
  category: paid-social
---

# Meta Signal & Tracking

The highest-weighted category in the OS, because everything downstream inherits its quality. An account with excellent creative optimising toward a mis-fired event is spending efficiently in the wrong direction — and no amount of creative testing will ever surface that.

## The core question

**Is the thing Meta optimises toward the thing that makes you money?**

Almost always the honest answer is "no, it's a proxy". The job is to shorten the distance between the proxy and the money.

| Pillar | Common proxy | The money | The gap to close |
|--------|--------------|-----------|------------------|
| Service | Lead form submit | Closed deal | Send qualified / booked / attended / won back as conversions |
| E-commerce | Purchase | Contribution margin | Send net-of-returns value; flag new vs returning |

## What to check

**Event integrity**
- Is the pixel firing, and firing once? Duplicate events inflate conversion counts and deflate reported cost — a doubled event halves your apparent CPA.
- Is CAPI live, and deduplicated against the browser pixel via a shared `event_id`? Missing dedup is the single most common cause of inflated counts.
- Is CAPI actually still firing? Check the last server-side fire time, not just that the dataset exists. Stale CAPI streams are common and silent.
- **Event Match Quality** score per event. Below ~6.0 means Meta is failing to match conversions to people, which degrades optimisation. Add email, phone, `fbc`/`fbp`, external ID.
- Custom conversions: are any duplicates of each other? A `PageView`-on-thank-you-page and a `CompleteRegistration`-on-thank-you-page are the same event counted twice.

**Optimisation-event choice**
- Is each ad set optimising for the truest event that clears ~50/week? Optimising for a later, more valuable event beats a cheap early one — but only if volume supports it. Below ~50/week the ad set sits in Learning Limited and the "better" event costs more than the proxy would have.
- **Service:** if lead volume supports it, optimise for a qualified-lead custom conversion rather than raw Lead. This is often the single highest-leverage change in a lead-gen account.
- **E-comm:** value optimisation needs consistent value parameters. Check they're present and correct before recommending it.

**Attribution**
- What window is set per ad set? **Mixed windows inside one account is a finding, not a footnote** — costs measured on 7-day-click/1-day-view and 1-day-click are not comparable, and any ranking across them is invalid.
- Does the reported conversion count reconcile against CRM or Shopify? A 20–30% platform over-count is normal from view-through and cross-device; a 2× gap is a tracking bug.

**Down-funnel return path**
- Service: is there an offline conversion dataset or CRM integration sending closed-won back?
- E-comm: are refunds and returns being deducted?
- If neither exists, this is almost always the top gap in the account.

## The double-count trap

Meta's `Leads` action type folds `leadgen.other` and `onsite_conversion.lead_grouped` together — the same Instant Form submission counted under two labels. On IF campaigns the `Leads` column reads roughly **2× the real count**, so `Cost per lead` reads roughly **half** the true cost.

Check it: compare `Leads` against `Meta leads` on any Instant Form campaign. If the ratio is near 2:1, the double-count is live. Use **Cost per result** — it is already de-duplicated and it self-labels the result type — or `Meta leads` for volume. Never rank campaigns on plain `Cost per lead` in an account that runs Instant Forms.

## Output

A findings list with severity, plus an **event map**: every event currently firing, what triggers it, which ad sets optimise for it, its weekly volume, its EMQ, and whether it is the right target. Recommend the shortest path from current proxy to money.

## Hard rules

- Never recommend a new optimisation event without checking it clears ~50/week.
- Never recommend a change to attribution windows without stating that historical comparisons break at the change point.
- Never estimate a conversion count that tracking failed to capture.
- Never write customer PII into the output.

---
*Built by Ankit kumar | HMM | helpmemarketing.com*
