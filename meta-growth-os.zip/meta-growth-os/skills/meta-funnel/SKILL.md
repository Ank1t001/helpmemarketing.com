---
name: meta-funnel
description: "Audit and fix everything after the Meta ad click — landing page performance, landing-page-view rate, form design, checkout friction, and the down-funnel layer the ad platform cannot see (lead to close for service, cart to purchase and returns for e-commerce). Use when the user asks about landing page performance, why clicks don't convert, my leads are bad quality, no-show rate, cart abandonment, checkout drop-off, post-click experience, Instant Form vs landing page, or lead quality. Stage 2 and Stage 5 specialist in the HMM Meta Growth OS."
metadata:
  author: AnkitK
  brand: "HMM | helpmemarketing.com"
  version: "1.0.0"
  category: paid-social
---

# Meta Funnel & Post-Click

The layer where the money is decided and where almost no account has data. Fixes here compound across every campaign at once, which is why funnel work usually outranks anything you could do inside the ad account.

## First: the click-to-page leak

**Landing page views ÷ Outbound clicks.** Not link clicks — on Instant Form campaigns link clicks never leave Meta, so the link-click version of this ratio is meaningless on any account running forms.

A material gap between outbound clicks and landing page views means people paid for are never seeing the page: slow load, redirect chains, interstitials, or a broken mobile experience. Meta traffic is overwhelmingly mobile, so a desktop-optimised page quietly caps everything upstream. Nothing in the ad account fixes this, and no creative test is meaningful until it's closed.

---

## Service & Lead Generation

### The trade you are actually making

Instant Forms reliably produce **cheaper leads and worse ones**. Landing pages produce fewer, more expensive, better-qualified leads. Both are legitimate. The error is comparing them on cost per lead.

Compare on **cost per qualified lead**, or better, cost per closed deal. It is completely normal for a form to win on CPL by 2–3× and lose on cost per closed deal. An operator who only reads the CPL column will systematically shift budget toward the worse channel — and the platform will help them do it, because the platform can only see the proxy.

### Stage rates to instrument

| Stage | Typical range | A bad number means |
|-------|---------------|-------------------|
| Click → lead (Instant Form) | 5–18% | Form friction, or the offer isn't worth the details |
| Click → lead (landing page) | 2–8% | Lower by design — the trade is quality |
| Lead → qualified | 20–50% | Targeting or form is inviting the wrong people |
| Qualified → appointment | 30–60% | Follow-up speed dominates; minutes beat hours |
| **Appointment → attended** | 60–80% | Above ~40% no-show means the lead never really committed |
| Attended → closed | 15–40% | Sales problem — but check whether one campaign feeds all the losses |

The stage rates below "lead" are practitioner ranges, not a large public dataset. Replace them with the account's own numbers as soon as 90 days of CRM history exists.

### Raising lead quality deliberately

Each of these raises CPL and raises quality more:
- Add a qualifying question to the form
- Turn off pre-fill on the field that matters most
- Add a manual confirmation step
- Move from Instant Form to landing page for the highest-value offer
- Send *qualified* leads back as the optimisation event

### Fixing no-shows

Treat a high no-show rate as a targeting and friction problem, not a reminder-email problem. Check whether it concentrates in one campaign or audience — it usually does. Then add friction at the point of booking rather than nudges after it.

---

## E-commerce

### Stage rates to instrument

| Stage | Average | Good | Top |
|-------|---------|------|-----|
| Add-to-cart rate | 6–7.5% | 8–10% | 10%+ |
| **Cart → checkout initiated** | 40–50% | 55–65% | 65%+ |
| Checkout → purchase | 20–40% | 45–55% | 55–70% |
| Cart abandonment | ~70% | <67% | <60% |
| Site-wide purchase CVR | 1.9–3% | 3–4% | 4–5%+ |

Cart → checkout is the biggest leak in most stores: 50–60% of cart additions never reach checkout. Cart abandonment has sat near 70% since 2006 — treat claims of radical improvement with suspicion.

Paid cold traffic converts below site-wide rates. Meta's median ad-click purchase CVR is around 1.6% against a 1.9–3% site-wide figure; that gap is normal, not a fault.

### Where to look first

Multiply the gap, don't chase the biggest number. Moving cart → checkout from 45% to 60% is a **33% revenue lift at identical ad spend**, larger than almost any creative change and it compounds across every campaign simultaneously.

Mobile vs desktop is the other structural check: 1.8–2.9% mobile against 3.5–4.0% desktop, on traffic that is overwhelmingly mobile.

### Returns and margin

Returns are invisible to the ad platform and vary by campaign — cheap traffic returns more. Pull return rate by campaign before concluding which campaign is cheapest. A campaign with 15% lower CPA and 12 points more returns is the more expensive one.

---

## Output

A funnel table with the account's own rate at each stage against the range, the click-to-page leak quantified, the single largest leak identified by multiplied impact, and fixes ranked by compounding effect rather than by ease.

## Hard rules

- Always divide by outbound clicks, not link clicks, when measuring page arrival.
- Never compare Instant Form and landing page on cost per lead.
- Never conclude a campaign is cheapest without return rate (E-comm) or close rate (Service).
- Never present practitioner ranges as if they were measured benchmarks — mark them.

---
*Built by Ankit kumar | HMM | helpmemarketing.com*
