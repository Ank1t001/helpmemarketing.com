# Meta Ads Benchmark Reference

Compiled 18 August 2026. Every table carries its source, sample and confidence.
Read the confidence column before quoting anything to a client.

---

## Service & Lead Generation — Leads objective

**Source:** WordStream / LocaliQ. 726 US lead-objective campaigns, 1 Apr 2024 – 30 Jun 2025,
medians, minimum 2 active campaigns per subcategory. **Confidence: HIGH.**

| Vertical | CTR | CPC | CVR | CPL |
|---|---|---|---|---|
| Restaurants & Food | 2.97% | $0.74 | 18.25% | $3.16 |
| Real Estate | 3.75% | $1.57 | 9.53% | $16.61 |
| Career & Employment | 2.81% | $0.86 | 5.77% | $17.64 |
| Arts & Entertainment | 3.92% | $1.08 | 9.34% | $18.17 |
| Attorneys & Legal Services | 2.11% | $4.10 | 10.53% | $18.17 |
| Sports & Recreation | 3.41% | $1.07 | 5.48% | $19.30 |
| Education & Instruction | 1.86% | $1.65 | 10.08% | $28.22 |
| Personal Services | 1.99% | $2.08 | 6.51% | $30.57 |
| Industrial & Commercial | 2.08% | $1.80 | 9.34% | $37.34 |
| Furniture | 1.48% | $2.18 | 3.77% | $40.04 |
| Home & Home Improvement | 1.94% | $2.23 | 5.22% | $41.26 |
| Physicians & Surgeons | 3.02% | $2.23 | 4.51% | $47.47 |
| Beauty & Personal Care | 2.55% | $3.06 | 5.29% | $51.42 |
| Health & Fitness | 1.72% | $2.64 | 5.63% | $52.98 |
| Dentists & Dental Services | 1.05% | $9.78 | 6.38% | $76.71 |
| **All-industry median** | **2.59%** | **$1.92** | **7.72%** | **$27.66** |

Traffic objective, same source, 554 campaigns: **CTR 1.71%, CPC $0.70.**
Never compare a lead-objective campaign against these.

Note the inverse pattern: Dentists carry the lowest CTR and highest CPC yet a mid-range
CVR. Expensive clicks in a competitive vertical are a market condition, not a failure.

---

## E-commerce — Sales objective

**Source:** Triple Whale. ~35,000 e-commerce brands, 1 Jan – 31 Dec 2025, medians,
YoY vs 2024. **Confidence: HIGH.**

| Metric | Median | YoY |
|---|---|---|
| ROAS | 1.86× | +1.3% |
| CPA / cost per purchase | $38.19 | +1.0% |
| Purchase CVR | 1.60% | +8.3% |
| CTR | 2.19% | +13.5% |
| CPM | $14.19 | +20.0% |
| AOV | $71.69 | +2.7% |
| MER (total revenue ÷ total ad spend) | 0.49 | — |

**Every one of 15 verticals saw CPM rise**, between +8.08% and +38.03%.

Split by intent — **confidence: MEDIUM**, secondary aggregation:
prospecting ROAS ~2.11×, retargeting ~3.61×. Blending them flatters weak prospecting.

Vertical highlights: best ROAS Automotive 2.54×, Sports & Outdoors 2.28×,
Travel Accessories 2.25×; Health & Wellness 1.50× on a 2.70% CTR with CPM up 38%.
Lowest CPA Lifestyle & Boutique $29.99, Baby $30.04, Books & Music $30.25;
highest Electronics $49.48, Travel Accessories $48.37.

**The margin arithmetic.** Median CPA $38.19 against median AOV $71.69 means the median
brand spends 53% of order value acquiring the order. Break-even ROAS = 1 ÷ contribution
margin; at 40% margin that is 2.5×, above the median. The median advertiser in this
dataset is not profitable on paid alone.

---

## Creative

**Source:** AdSights, aggregating Motion Creative (2025–26), Triple Whale and DTC
aggregators; hold-rate bands from AdLibrary. **Confidence: MEDIUM** — practitioner
aggregation, not a single disclosed dataset.

Hook rate = 3-second video plays ÷ impressions.

| Placement / temperature | Range | Median |
|---|---|---|
| Cold prospecting, in-feed | 18–28% | ~22% |
| Reels | 24–36% | ~30% |
| Stories | 22–32% | ~27% |
| Retargeting / warm | 30–45% | ~36% |

Retargeting figures are **not** a creative-quality signal — warm audiences stop because
they recognise the brand.

| Hold rate measure | Healthy | Best in class | Act below |
|---|---|---|---|
| 15-second ÷ 3-second | 15–25% | 25–30% | 10% |
| Video plays at 75% ÷ 3-second | 8–15% | — | — |

Roughly 70% of retention problems are pacing problems — fixable by re-editing.

---

## E-commerce funnel

**Source:** Blend Commerce, Growth Suite, Mida App, Baymard Institute (cart abandonment
from 50 studies). **Confidence: MEDIUM.**

| Stage | Average | Good | Top |
|---|---|---|---|
| Add-to-cart rate | 6–7.5% | 8–10% | 10%+ |
| Cart → checkout initiated | 40–50% | 55–65% | 65%+ |
| Checkout → purchase | 20–40% | 45–55% | 55–70% |
| Cart abandonment | ~70.2% | <67% | <60% |
| Site-wide purchase CVR | 1.9–3% | 3–4% | 4–5%+ |
| Mobile CVR | 1.8–2.9% | — | — |
| Desktop CVR | 3.5–4.0% | — | — |

Cart → checkout is the biggest leak in most stores. Moving it from 45% to 60% is a 33%
revenue lift at identical ad spend.

---

## Service funnel

**Confidence: LOW** — practitioner ranges. No large public dataset covers CRM-side
conversion for paid social. Replace with the account's own numbers after 90 days.

| Stage | Typical range |
|---|---|
| Click → lead (Instant Form) | 5–18% |
| Click → lead (landing page) | 2–8% |
| Lead → qualified | 20–50% |
| Qualified → appointment booked | 30–60% |
| Appointment → attended | 60–80% |
| Attended → closed | 15–40% |

---

## Placement CTR

**Confidence: LOW** — aggregator, sample not disclosed. Use for relative ordering only.

Facebook Reels 2.14% · Instagram Reels 2.08% · Instagram Stories 1.87% ·
Facebook Stories 1.72% · Carousel 1.62% · Instagram Feed 1.41% · Facebook Feed 1.32% ·
Facebook Right Column 0.72% · **Audience Network 0.58%**

Objective-level CPM, same source and confidence: Reach $7.19 · Video Views $6.83 ·
Traffic $8.94 · Engagement $9.62 · App Install $11.82 · Lead Generation $12.37 ·
Catalog Sales $13.41 · Conversions $14.68.

---

## Universal operating thresholds

Mechanical properties of Meta's delivery system, not industry averages. These hold
regardless of vertical or market.

| Threshold | Value |
|---|---|
| Learning phase exit | ~50 optimisation events per ad set per week |
| Judgement window | 3–7 days **or** ~50 conversions, whichever is later |
| Frequency ceiling (cold) | 3–4 |
| Audience overlap — consolidate above | 30% |
| Relevance diagnostics minimum | 500 impressions |
| Creative test significance | ~100 conversions per variant for a 20% difference |

---

## Where sources disagree

| Metric | Source A (no disclosed sample) | Source B (35k brands, full year) | Gap |
|---|---|---|---|
| E-commerce ROAS | 3.71× | 1.86× | 2.0× |
| CPM | $11.54 | $14.19 | 23% |
| E-commerce CVR | 2.81% | 1.60% | 1.8× |

This library uses B. A appears only where marked low confidence. The general lesson:
when a benchmark post does not state its sample size and date range, treat it as folklore.

---

## Sources

1. WordStream / LocaliQ — https://www.wordstream.com/blog/facebook-ads-benchmarks-2025 — HIGH
2. Triple Whale — https://www.triplewhale.com/blog/facebook-ads-benchmarks — HIGH
3. AdSights (thumbstop rate) — https://www.adsights.ai/resources/glossary/metrics/thumbstop-rate-tsr — MEDIUM
4. AdLibrary (hold rate) — https://adlibrary.com/posts/hold-rate — MEDIUM
5. Chatboq / Blend Commerce / Growth Suite / Mida / Baymard — https://chatboq.com/blogs/ecommerce-funnel-benchmarks — MEDIUM
6. rule1.ai — https://rule1.ai/articles/facebook-ads-benchmarks — MEDIUM
7. Digital Applied — https://www.digitalapplied.com/blog/facebook-ads-benchmarks-2026-cpc-cpm-ctr-industry — LOW
