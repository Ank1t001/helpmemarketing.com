---
name: meta-benchmarks
description: "Meta Ads benchmark library and target-setting — published industry medians for Service/Lead Gen and E-commerce with source and confidence marked on every figure, plus the method for deriving targets from unit economics and building an account's own baseline. Use when the user asks what's a good CPL, what's a good ROAS, what's a good CTR/CPM/hook rate, industry benchmarks, how do I compare, is my CPA normal, what should I target, or benchmarks for my vertical. Stage 1 and Stage 7 specialist in the HMM Meta Growth OS."
metadata:
  author: AnkitK
  brand: "HMM | helpmemarketing.com"
  version: "1.0.0"
  category: paid-social
---

# Meta Benchmarks

Two jobs, and the second matters more than the first.

1. Look up what published data says the median advertiser achieves.
2. **Derive the target the account should actually hit from its own unit economics** — because the median advertiser is, definitionally, average, and in e-commerce the median advertiser is not profitable on paid alone.

Full figures with sources live in `references/benchmarks.md`. Read it before quoting anything.

## Lead with the derived target, not the industry median

**Service:** `Target CPL = (deal value × gross margin × close rate) ÷ target payback multiple`

A $4,000 deal at 60% margin closing 20% of leads generates $480 of gross profit per lead. At a 3× payback the target CPL is $160 — regardless of whether the industry median is $28 or $77.

**E-commerce:** `Break-even ROAS = 1 ÷ contribution margin`

At 40% contribution margin after COGS, shipping, fees and returns, break-even is 2.5×. Set the goal above break-even by whatever payback period the business can finance. Note that 2.5× sits *above* the published median of 1.86× — which is the whole point.

If unit economics are unavailable, say so plainly and mark every subsequent judgement as relative. Do not substitute an industry median for a target the business never set.

## Confidence marking is mandatory

Published Meta benchmarks disagree with each other badly. Two sources give e-commerce ROAS as 3.71× and 1.86× for overlapping periods; CPM as $11.54 and $14.19; CVR as 2.81% and 1.60%. One disclosed a 35,000-brand sample and a full calendar year; the other disclosed nothing.

Every figure you quote carries a confidence level:

- **High** — large disclosed sample, stated methodology and date range
- **Medium** — credible aggregator, partial methodology
- **Low** — widely repeated, no disclosed sample. Directional only

When a benchmark post does not state its sample size and date range, treat the numbers as folklore. Never present a low-confidence figure as fact to a client.

## Headline medians

**Service & Lead Generation** — WordStream/LocaliQ, 726 US lead-objective campaigns, Apr 2024–Jun 2025, medians. *High confidence.*
CPL $27.66 · lead-form CVR 7.72% · CTR 2.59% · CPC $1.92. Traffic objective: CTR 1.71%, CPC $0.70.

The all-industry CPL is nearly useless alone — the vertical range runs $3.16 (restaurants) to $76.71 (dentists), a 24× spread inside one headline. Use the vertical table in the reference file.

**E-commerce** — Triple Whale, ~35,000 brands, Jan–Dec 2025, medians. *High confidence.*
ROAS 1.86× · CPA $38.19 · purchase CVR 1.60% · CTR 2.19% · CPM $14.19 · AOV $71.69 · MER 0.49. Prospecting ROAS ~2.11×, retargeting ~3.61× (*medium*).

Every vertical in that dataset saw CPM rise year-over-year, between +8% and +38%. A CPM increase in an account is now the base case, not an anomaly — measure yours against that, not against zero.

**Creative** — *medium confidence*, practitioner aggregation.
Cold prospecting hook rate 18–28% (median ~22%); Reels 24–36%; Stories 22–32%; retargeting 30–45% but **not a creative-quality signal**. Hold rate 15–25% healthy, 25–30% best in class, act below 10%.

**Universal operating thresholds** — mechanical properties of the delivery system, not industry averages.
~50 optimisation events per ad set per week to exit learning · judgement window 3–7 days *or* ~50 conversions, whichever is later · frequency ceiling 3–4 on cold · consolidate above 30% audience overlap · relevance diagnostics need 500 impressions · ~100 conversions per variant for a 20% difference to be trustworthy.

## Six ways benchmarks mislead

| Trap | What goes wrong |
|------|-----------------|
| Mixed objectives | Lead-objective CPC $1.92 vs traffic-objective $0.70 — 2.7× apart. The most common error on this list |
| Mixed temperature | Retargeting and prospecting hook rates are different metrics wearing one name |
| Mixed attribution | 7-day-click/1-day-view vs 1-day-click can differ 40%+ on identical spend |
| Survivorship | Platform datasets over-represent brands that stayed long enough to be measured |
| Median ≠ target | Hitting the benchmark is not the same as succeeding |
| Geography | Most published data is US. CPMs vary several-fold by market |

## Building the account's own benchmark set

The only benchmark that reliably works is **the account 90 days ago** — same product, margin, market, attribution setting and seasonality. Every confound that makes external medians unreliable is held constant.

1. Pull 90 days at campaign level
2. **Segment before averaging** — by form type (Service) or prospecting vs retargeting (E-comm)
3. Record the median *and the range*, not the mean. The range sizes the prize from reallocation
4. Set thresholds as multiples of the account's own median — "investigate above 1.5× for 7+ days, kill above 2.5×" travels across verticals and currencies where absolute figures don't
5. Re-baseline quarterly

Use published benchmarks for exactly two jobs: sanity-checking a brand-new account with no history, and detecting *structural* mismatch — a CPC 4× the vertical median means something is genuinely wrong. For anything finer, the account's own trend line wins.

## Hard rules

- Never quote a figure without its confidence level and source.
- Never present an industry median as a target.
- Never compare across objectives, attribution windows or audience temperature.
- Never apply US benchmarks to a non-US account without flagging it.

---
*Built by Ankit kumar | HMM | helpmemarketing.com*
