---
name: meta-drift
description: "Capture a Meta Ads performance baseline and detect regressions between runs — cost, delivery, structure and creative drift, with noise filtering so the learning phase and small samples don't trigger false alarms. Use when the user asks to monitor my Meta account, track changes, did anything break, compare to last month, set a baseline, watch for regressions, or wants ongoing monitoring rather than a one-off audit. Stage 6 specialist in the HMM Meta Growth OS."
metadata:
  author: AnkitK
  brand: "HMM | helpmemarketing.com"
  version: "1.0.0"
  category: paid-social
---

# Meta Drift & Monitoring

Answers one question: **did anything break?** That is deliberately narrower than "how are we trending?" — the trending question belongs to `meta-report`. Conflating them produces alerts nobody reads.

## Baseline

Capture after fixes ship, not before. A baseline taken mid-repair encodes the broken state as normal.

Record per campaign and per ad set: spend, cost per result (with its result-type label), Meta leads or purchases, CPM, CTR (link), frequency, cost per 1,000 reached, delivery status, delivery sub-status, performance goal, attribution setting, active creative count, and the date range and currency.

Record the **structural fingerprint** too: number of campaigns, ad sets and active ads, plus which events are firing and at what weekly volume. Most silent breakage is structural — a paused ad set, a stopped CAPI stream, a rejected ad — not a cost movement.

## What counts as drift

| Category | Regression |
|----------|-----------|
| Cost | Cost per result up >25% vs baseline, sustained 7+ days, past the judgement window |
| Delivery | Any move to `error`, `WITH_ISSUES`, `DISAPPROVED`, or zero delivery on a funded entity |
| Learning | An ad set that had exited learning re-entering it, or a new `FAIL` sub-status |
| Signal | An event whose weekly volume dropped >30%, or a CAPI stream whose last server fire time stopped advancing |
| Structure | Ad sets or ads paused, added or edited since baseline — with who and when if the activity log is available |
| Creative | A previously-winning ad with cost per result rising two consecutive weeks |
| Audience | Frequency crossing 4 on cold, or reach flat while spend rises |
| Attribution | Any change to attribution setting — this invalidates comparisons at the change point |

## Noise filtering

This is what makes the skill worth running. **Do not log a regression when:**

- The entity is inside the learning phase
- Fewer than ~50 conversions have accrued since baseline
- Fewer than 7 days have passed on a cost movement
- The movement is within normal weekly variance for that entity — compare against its own historical spread, not against zero
- A known deliberate change explains it (a budget increase will raise cost per result temporarily; that is the reset, not a regression)

A monitor that reports every fluctuation trains the user to ignore it, and then the real alert gets ignored too.

## Attribution and comparability

Before comparing any two periods, confirm the attribution setting is identical. If it changed, say so and stop the cost comparison there — the numbers are not comparable and presenting them side by side is misleading regardless of the disclaimer attached.

Same for currency, date-range length and any account-level breakdown gating that changed.

## Output

A dated drift log entry: what changed, what did not, what was suppressed as noise and why. Regressions ranked by spend at risk. If nothing broke, say so in one line — **a silent week is a good week** and should read like one, not like a blank report.

## Cadence

Run after any deployment or structural change. On a schedule, weekly for active programmes and monthly for maintenance. Report only when something changed, broke or crossed a threshold.

## Hard rules

- Never log a regression inside the judgement window.
- Never compare across attribution settings, currencies or unequal date ranges.
- Never fabricate a baseline for a period that was not captured.
- Never report a suppressed-as-noise item as a finding.

---
*Built by Ankit kumar | HMM | helpmemarketing.com*
